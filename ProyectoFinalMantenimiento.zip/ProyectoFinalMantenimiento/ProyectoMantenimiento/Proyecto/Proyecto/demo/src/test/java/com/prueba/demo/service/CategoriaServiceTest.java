package com.prueba.demo.service;

import com.prueba.demo.model.Categoria;
import com.prueba.demo.model.RolUsuario;
import com.prueba.demo.model.Usuario;
import com.prueba.demo.repository.CategoriaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class CategoriaServiceTest {

    private CategoriaService categoriaService;
    private CategoriaRepository categoriaRepository;

    @BeforeEach
    void setUp() {
        categoriaRepository = mock(CategoriaRepository.class);
        categoriaService = new CategoriaService();
        // inyectar el mock en el campo privado
        ReflectionTestUtils.setField(categoriaService, "categoriaRepository", categoriaRepository);
    }

    @Test
    @DisplayName("crearCategoria: nombre duplicado lanza IllegalArgumentException")
    void crearCategoria_NombreDuplicado() {
        Categoria c = new Categoria();
        c.setNombre("Test");

        when(categoriaRepository.existsByNombre("Test")).thenReturn(true);

        assertThrows(IllegalArgumentException.class,
                     () -> categoriaService.crearCategoria(c));
        verify(categoriaRepository).existsByNombre("Test");
        verify(categoriaRepository, never()).save(any());
    }

    @Test
    @DisplayName("crearCategoria: guarda correctamente con nombre único")
    void crearCategoria_Valido() {
        Categoria c = new Categoria();
        c.setNombre("Unique");
        c.setDescripcion("Desc");

        when(categoriaRepository.existsByNombre("Unique")).thenReturn(false);
        when(categoriaRepository.save(any(Categoria.class))).thenAnswer(inv -> inv.getArgument(0));

        Categoria resultado = categoriaService.crearCategoria(c);
        assertThat(resultado.getNombre()).isEqualTo("Unique");
        assertThat(resultado.getDescripcion()).isEqualTo("Desc");

        verify(categoriaRepository).existsByNombre("Unique");
        verify(categoriaRepository).save(c);
    }

    @Test
    @DisplayName("eliminarCategoria: usuario no ADMIN lanza SecurityException")
    void eliminarCategoria_NoAdmin() {
        Usuario u = new Usuario();
        u.setId(1L);
        u.setRol(RolUsuario.REDACTOR);

        assertThrows(SecurityException.class,
                     () -> categoriaService.eliminarCategoria(5L, u));
        verify(categoriaRepository, never()).deleteById(any());
    }

    @Test
    @DisplayName("eliminarCategoria: ADMIN elimina correctamente")
    void eliminarCategoria_Admin() {
        Usuario admin = new Usuario();
        admin.setId(2L);
        admin.setRol(RolUsuario.ADMIN);

        categoriaService.eliminarCategoria(7L, admin);
        verify(categoriaRepository).deleteById(7L);
    }

    @Test
    @DisplayName("listarTodas: devuelve lista retornada por repositorio")
    void listarTodas() {
        Categoria c1 = new Categoria(); c1.setId(1L);
        Categoria c2 = new Categoria(); c2.setId(2L);
        when(categoriaRepository.findAll()).thenReturn(Arrays.asList(c1, c2));

        List<Categoria> todas = categoriaService.listarTodas();
        assertThat(todas).hasSize(2).containsExactly(c1, c2);

        verify(categoriaRepository).findAll();
    }

    @Test
    @DisplayName("actualizarCategoria: categoría no existe lanza NoSuchElementException")
    void actualizarCategoria_NoExiste() {
        when(categoriaRepository.findById(10L)).thenReturn(Optional.empty());

        // Aunque se pasa un usuario distinto, el método ignora el parámetro y usa un ADMIN interno
        assertThrows(java.util.NoSuchElementException.class,
                     () -> categoriaService.actualizarCategoria(10L, new Categoria(), new Usuario()));
        verify(categoriaRepository).findById(10L);
        verify(categoriaRepository, never()).save(any());
    }

    @Test
    @DisplayName("actualizarCategoria: ADMIN actualiza correctamente")
    void actualizarCategoria_Admin() {
        Categoria existing = new Categoria();
        existing.setId(3L);
        existing.setNombre("Old");
        existing.setDescripcion("OldDesc");

        when(categoriaRepository.findById(3L)).thenReturn(Optional.of(existing));
        when(categoriaRepository.save(any(Categoria.class))).thenAnswer(inv -> inv.getArgument(0));

        Categoria cambios = new Categoria();
        cambios.setNombre("New");
        cambios.setDescripcion("NewDesc");

        // Se puede pasar cualquier usuario; el método internamente fuerza ADMIN
        Usuario u = new Usuario();
        u.setId(5L);
        u.setRol(RolUsuario.LECTOR); // irrelevante, porque se sobrescribe

        Categoria resultado = categoriaService.actualizarCategoria(3L, cambios, u);
        assertThat(resultado.getId()).isEqualTo(3L);
        assertThat(resultado.getNombre()).isEqualTo("New");
        assertThat(resultado.getDescripcion()).isEqualTo("NewDesc");

        verify(categoriaRepository).findById(3L);
        verify(categoriaRepository).save(existing);
    }
}
