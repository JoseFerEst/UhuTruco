package com.prueba.demo.service;

import com.prueba.demo.model.Articulo;
import com.prueba.demo.model.Categoria;
import com.prueba.demo.model.RolUsuario;
import com.prueba.demo.model.Usuario;
import com.prueba.demo.repository.ArticuloRepository;
import com.prueba.demo.repository.CategoriaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class ArticuloServiceTest {

    private ArticuloService articuloService;
    private ArticuloRepository articuloRepository;
    private CategoriaRepository categoriaRepository;

    @BeforeEach
    void setUp() {
        articuloRepository = mock(ArticuloRepository.class);
        categoriaRepository = mock(CategoriaRepository.class);
        articuloService = new ArticuloService();
        // Inyectar los mocks en los campos privados del servicio:
        ReflectionTestUtils.setField(articuloService, "articuloRepository", articuloRepository);
        ReflectionTestUtils.setField(articuloService, "categoriaRepository", categoriaRepository);
    }

    @Test
    @DisplayName("guardarArticulo: categoria nula lanza IllegalArgumentException")
    void guardarArticulo_CategoriaNull() {
        Articulo a = new Articulo();
        a.setCategoria(null);

        Usuario u = new Usuario();
        u.setId(1L);
        u.setRol(RolUsuario.REDACTOR);

        assertThrows(IllegalArgumentException.class,
                     () -> articuloService.guardarArticulo(a, u));
        verifyNoInteractions(articuloRepository);
    }

    @Test
    @DisplayName("guardarArticulo: categoria inexistente lanza IllegalArgumentException")
    void guardarArticulo_CategoriaInexistente() {
        Articulo a = new Articulo();
        Categoria c = new Categoria();
        c.setId(5L);
        a.setCategoria(c);

        when(categoriaRepository.existsById(5L)).thenReturn(false);

        Usuario u = new Usuario();
        u.setId(2L);
        u.setRol(RolUsuario.REDACTOR);

        assertThrows(IllegalArgumentException.class,
                     () -> articuloService.guardarArticulo(a, u));
        verify(categoriaRepository).existsById(5L);
        verifyNoInteractions(articuloRepository);
    }

    @Test
    @DisplayName("guardarArticulo: guarda correctamente y asigna redactor")
    void guardarArticulo_Valido() {
        Articulo a = new Articulo();
        Categoria c = new Categoria();
        c.setId(3L);
        a.setCategoria(c);

        when(categoriaRepository.existsById(3L)).thenReturn(true);
        when(articuloRepository.save(any(Articulo.class))).thenAnswer(inv -> inv.getArgument(0));

        Usuario u = new Usuario();
        u.setId(10L);
        u.setRol(RolUsuario.REDACTOR);

        articuloService.guardarArticulo(a, u);

        ArgumentCaptor<Articulo> captor = ArgumentCaptor.forClass(Articulo.class);
        verify(articuloRepository).save(captor.capture());

        Articulo guardado = captor.getValue();
        assertThat(guardado.getAutor()).isEqualTo(u);
        assertThat(guardado.getCategoria().getId()).isEqualTo(3L);
    }

    @Test
    @DisplayName("eliminarArticulo: articulo no encontrado lanza NoSuchElementException")
    void eliminarArticulo_NoEncontrado() {
        when(articuloRepository.findById(7L)).thenReturn(Optional.empty());

        Usuario u = new Usuario();
        u.setId(1L);
        u.setRol(RolUsuario.ADMIN);

        assertThrows(java.util.NoSuchElementException.class,
                     () -> articuloService.eliminarArticulo(7L, u));
    }

    @Test
    @DisplayName("eliminarArticulo: usuario no admin ni redactor lanza SecurityException")
    void eliminarArticulo_SinPermiso() {
        Articulo a = new Articulo();
        a.setId(8L);
        Usuario autor = new Usuario();
        autor.setId(5L);
        autor.setRol(RolUsuario.REDACTOR);
        a.setAutor(autor);

        when(articuloRepository.findById(8L)).thenReturn(Optional.of(a));

        Usuario otro = new Usuario();
        otro.setId(6L);
        otro.setRol(RolUsuario.REDACTOR);

        assertThrows(SecurityException.class,
                     () -> articuloService.eliminarArticulo(8L, otro));
        verify(articuloRepository).findById(8L);
        verify(articuloRepository, never()).delete(any(Articulo.class));
    }

    @Test
    @DisplayName("eliminarArticulo: admin elimina sin error")
    void eliminarArticulo_Admin() {
        Articulo a = new Articulo();
        a.setId(9L);
        Usuario autor = new Usuario();
        autor.setId(5L);
        autor.setRol(RolUsuario.REDACTOR);
        a.setAutor(autor);

        when(articuloRepository.findById(9L)).thenReturn(Optional.of(a));

        Usuario admin = new Usuario();
        admin.setId(1L);
        admin.setRol(RolUsuario.ADMIN);

        articuloService.eliminarArticulo(9L, admin);
        verify(articuloRepository).delete(a);
    }

    @Test
    @DisplayName("eliminarArticulo: autor elimina su articulo sin error")
    void eliminarArticulo_Autor() {
        Articulo a = new Articulo();
        a.setId(10L);
        Usuario autor = new Usuario();
        autor.setId(5L);
        autor.setRol(RolUsuario.REDACTOR);
        a.setAutor(autor);

        when(articuloRepository.findById(10L)).thenReturn(Optional.of(a));

        articuloService.eliminarArticulo(10L, autor);
        verify(articuloRepository).delete(a);
    }

    @Test
    @DisplayName("editarArticulo: usuario sin permiso lanza SecurityException")
    void editarArticulo_SinPermiso() {
        Articulo a = new Articulo();
        a.setId(11L);
        Usuario autor = new Usuario();
        autor.setId(5L);
        autor.setRol(RolUsuario.REDACTOR);
        a.setAutor(autor);

        when(articuloRepository.findById(11L)).thenReturn(Optional.of(a));

        Articulo cambios = new Articulo();
        cambios.setTitulo("T");
        cambios.setCuerpo("C");
        cambios.setCategoria(new Categoria());

        Usuario otro = new Usuario();
        otro.setId(6L);
        otro.setRol(RolUsuario.REDACTOR);

        assertThrows(SecurityException.class,
                     () -> articuloService.editarArticulo(11L, cambios, otro));
        verify(articuloRepository).findById(11L);
        verify(articuloRepository, never()).save(any());
    }

    @Test
    @DisplayName("editarArticulo: admin edita y devuelve artículo actualizado")
    void editarArticulo_Admin() {
        Articulo a = new Articulo();
        a.setId(12L);
        a.setTitulo("Viejo");
        a.setCuerpo("ViejoC");
        Categoria catOld = new Categoria();
        catOld.setId(2L);
        a.setCategoria(catOld);
        Usuario autor = new Usuario();
        autor.setId(5L);
        autor.setRol(RolUsuario.REDACTOR);
        a.setAutor(autor);

        when(articuloRepository.findById(12L)).thenReturn(Optional.of(a));
        when(articuloRepository.save(any(Articulo.class))).thenAnswer(inv -> inv.getArgument(0));

        Articulo cambios = new Articulo();
        cambios.setTitulo("Nuevo");
        cambios.setCuerpo("NuevoC");
        Categoria catNew = new Categoria();
        catNew.setId(3L);
        cambios.setCategoria(catNew);

        Usuario admin = new Usuario();
        admin.setId(1L);
        admin.setRol(RolUsuario.ADMIN);

        Articulo resultado = articuloService.editarArticulo(12L, cambios, admin);

        assertThat(resultado.getTitulo()).isEqualTo("Nuevo");
        assertThat(resultado.getCuerpo()).isEqualTo("NuevoC");
        assertThat(resultado.getCategoria().getId()).isEqualTo(3L);
    }

    @Test
    @DisplayName("editarArticulo: autor edita su artículo y devuelve actualizado")
    void editarArticulo_Autor() {
        Articulo a = new Articulo();
        a.setId(13L);
        a.setTitulo("OldT");
        a.setCuerpo("OldC");
        Categoria catOld = new Categoria();
        catOld.setId(4L);
        a.setCategoria(catOld);
        Usuario autor = new Usuario();
        autor.setId(7L);
        autor.setRol(RolUsuario.REDACTOR);
        a.setAutor(autor);

        when(articuloRepository.findById(13L)).thenReturn(Optional.of(a));
        when(articuloRepository.save(any(Articulo.class))).thenAnswer(inv -> inv.getArgument(0));

        Articulo cambios = new Articulo();
        cambios.setTitulo("Changed");
        cambios.setCuerpo("ChangedC");
        Categoria catChanged = new Categoria();
        catChanged.setId(5L);
        cambios.setCategoria(catChanged);

        Articulo resultado = articuloService.editarArticulo(13L, cambios, autor);

        assertThat(resultado.getTitulo()).isEqualTo("Changed");
        assertThat(resultado.getCuerpo()).isEqualTo("ChangedC");
        assertThat(resultado.getCategoria().getId()).isEqualTo(5L);
    }

    @Test
    @DisplayName("obtenerArticuloPorId: artículo no existe lanza IllegalArgumentException")
    void obtenerArticuloPorId_NoExiste() {
        when(articuloRepository.findById(20L)).thenReturn(Optional.empty());
        assertThrows(IllegalArgumentException.class,
                     () -> articuloService.obtenerArticuloPorId(20L));
    }

    @Test
    @DisplayName("obtenerArticuloPorId: devuelve artículo cuando existe")
    void obtenerArticuloPorId_Existe() {
        Articulo a = new Articulo();
        a.setId(21L);
        when(articuloRepository.findById(21L)).thenReturn(Optional.of(a));

        Articulo resultado = articuloService.obtenerArticuloPorId(21L);
        assertThat(resultado).isEqualTo(a);
    }
}
