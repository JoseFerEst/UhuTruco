package com.prueba.demo.service;

import com.prueba.demo.model.RolUsuario;
import com.prueba.demo.model.Usuario;
import com.prueba.demo.repository.UsuarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@DataJpaTest(
	    properties = {
	        "spring.datasource.url=jdbc:h2:mem:testdb;DB_CLOSE_DELAY=-1;MODE=MySQL",
	        "spring.datasource.driver-class-name=org.h2.Driver",
	        "spring.datasource.username=sa",
	        "spring.datasource.password=",
	        "spring.jpa.hibernate.ddl-auto=create-drop",
	        "spring.jpa.show-sql=true"
	    }
	)

class UsuarioServiceTest {

    private UsuarioService usuarioService;
    private UsuarioRepository usuarioRepository;

    @BeforeEach
    void setUp() {
        usuarioRepository = mock(UsuarioRepository.class);
        usuarioService = new UsuarioService();
        // Inyectar el mock en el campo privado
        ReflectionTestUtils.setField(usuarioService, "usuarioRepository", usuarioRepository);
    }

    @Test
    @DisplayName("crearRedactor: si quien llama no es ADMIN lanza SecurityException")
    void crearRedactor_SinPermiso() {
        Usuario redactor = new Usuario();
        redactor.setEmail("r@ej.com");

        Usuario noAdmin = new Usuario();
        noAdmin.setRol(RolUsuario.LECTOR);

        assertThrows(SecurityException.class,
                     () -> usuarioService.crearRedactor(redactor, noAdmin));
        verifyNoInteractions(usuarioRepository);
    }

    @Test
    @DisplayName("crearRedactor: ADMIN crea y guarda redactor con rol ADMIN")
    void crearRedactor_AdminValido() {
        Usuario redactor = new Usuario();
        redactor.setEmail("r@ej.com");

        Usuario admin = new Usuario();
        admin.setRol(RolUsuario.ADMIN);

        when(usuarioRepository.save(any(Usuario.class))).thenAnswer(inv -> inv.getArgument(0));

        Usuario resultado = usuarioService.crearRedactor(redactor, admin);

        assertThat(resultado.getRol()).isEqualTo(RolUsuario.ADMIN);
        verify(usuarioRepository).save(redactor);
    }

    @Test
    @DisplayName("listarRedactores: delega a repository.findByRol(REDACTOR)")
    void listarRedactores_DevuelveLista() {
        Usuario u1 = new Usuario(); u1.setId(1L);
        Usuario u2 = new Usuario(); u2.setId(2L);
        when(usuarioRepository.findByRol(RolUsuario.REDACTOR))
            .thenReturn(Arrays.asList(u1, u2));

        List<Usuario> lista = usuarioService.listarRedactores();
        assertThat(lista).containsExactly(u1, u2);
        verify(usuarioRepository).findByRol(RolUsuario.REDACTOR);
    }

    @Test
    @DisplayName("registrarLector: email ya registrado lanza IllegalArgumentException")
    void registrarLector_EmailDuplicado() {
        Usuario u = new Usuario();
        u.setEmail("dup@ej.com");

        when(usuarioRepository.existsByEmail("dup@ej.com")).thenReturn(true);

        assertThrows(IllegalArgumentException.class,
                     () -> usuarioService.registrarLector(u));
        verify(usuarioRepository).existsByEmail("dup@ej.com");
        verify(usuarioRepository, never()).save(any());
    }

    @Test
    @DisplayName("registrarLector: guarda usuario con rol LECTOR")
    void registrarLector_Valido() {
        Usuario u = new Usuario();
        u.setEmail("nuevo@ej.com");

        when(usuarioRepository.existsByEmail("nuevo@ej.com")).thenReturn(false);
        when(usuarioRepository.save(any(Usuario.class))).thenAnswer(inv -> inv.getArgument(0));

        Usuario resultado = usuarioService.registrarLector(u);
        assertThat(resultado.getRol()).isEqualTo(RolUsuario.LECTOR);
        verify(usuarioRepository).existsByEmail("nuevo@ej.com");
        verify(usuarioRepository).save(u);
    }

    @Test
    @DisplayName("registrarUsuario: email duplicado lanza IllegalArgumentException")
    void registrarUsuario_EmailDuplicado() {
        Usuario u = new Usuario();
        u.setEmail("dup2@ej.com");

        when(usuarioRepository.existsByEmail("dup2@ej.com")).thenReturn(true);

        assertThrows(IllegalArgumentException.class,
                     () -> usuarioService.registrarUsuario(u));
        verify(usuarioRepository).existsByEmail("dup2@ej.com");
        verify(usuarioRepository, never()).save(any());
    }

    @Test
    @DisplayName("registrarUsuario: guarda usuario con rol LECTOR")
    void registrarUsuario_Valido() {
        Usuario u = new Usuario();
        u.setEmail("nuevo2@ej.com");

        when(usuarioRepository.existsByEmail("nuevo2@ej.com")).thenReturn(false);
        when(usuarioRepository.save(any(Usuario.class))).thenAnswer(inv -> inv.getArgument(0));

        Usuario resultado = usuarioService.registrarUsuario(u);
        assertThat(resultado.getRol()).isEqualTo(RolUsuario.LECTOR);
        verify(usuarioRepository).existsByEmail("nuevo2@ej.com");
        verify(usuarioRepository).save(u);
    }

    @Test
    @DisplayName("registrarAdmin: email duplicado lanza IllegalArgumentException")
    void registrarAdmin_EmailDuplicado() {
        Usuario u = new Usuario();
        u.setEmail("dupadmin@ej.com");

        when(usuarioRepository.existsByEmail("dupadmin@ej.com")).thenReturn(true);

        assertThrows(IllegalArgumentException.class,
                     () -> usuarioService.registrarAdmin(u));
        verify(usuarioRepository).existsByEmail("dupadmin@ej.com");
        verify(usuarioRepository, never()).save(any());
    }

    @Test
    @DisplayName("registrarAdmin: guarda usuario con rol ADMIN")
    void registrarAdmin_Valido() {
        Usuario u = new Usuario();
        u.setEmail("nuevoadmin@ej.com");

        when(usuarioRepository.existsByEmail("nuevoadmin@ej.com")).thenReturn(false);
        when(usuarioRepository.save(any(Usuario.class))).thenAnswer(inv -> inv.getArgument(0));

        Usuario resultado = usuarioService.registrarAdmin(u);
        assertThat(resultado.getRol()).isEqualTo(RolUsuario.ADMIN);
        verify(usuarioRepository).existsByEmail("nuevoadmin@ej.com");
        verify(usuarioRepository).save(u);
    }

    @Test
    @DisplayName("registrarRedactor: email duplicado lanza IllegalArgumentException")
    void registrarRedactor_EmailDuplicado() {
        Usuario u = new Usuario();
        u.setEmail("dupred@ej.com");

        when(usuarioRepository.existsByEmail("dupred@ej.com")).thenReturn(true);

        assertThrows(IllegalArgumentException.class,
                     () -> usuarioService.registrarRedactor(u));
        verify(usuarioRepository).existsByEmail("dupred@ej.com");
        verify(usuarioRepository, never()).save(any());
    }

    @Test
    @DisplayName("registrarRedactor: guarda usuario con rol REDACTOR")
    void registrarRedactor_Valido() {
        Usuario u = new Usuario();
        u.setEmail("nuevored@ej.com");

        when(usuarioRepository.existsByEmail("nuevored@ej.com")).thenReturn(false);
        when(usuarioRepository.save(any(Usuario.class))).thenAnswer(inv -> inv.getArgument(0));

        Usuario resultado = usuarioService.registrarRedactor(u);
        assertThat(resultado.getRol()).isEqualTo(RolUsuario.REDACTOR);
        verify(usuarioRepository).existsByEmail("nuevored@ej.com");
        verify(usuarioRepository).save(u);
    }

    @Test
    @DisplayName("eliminarUsuario: si quien llama no es ADMIN lanza SecurityException")
    void eliminarUsuario_SinPermiso() {
        Usuario noAdmin = new Usuario();
        noAdmin.setRol(RolUsuario.LECTOR);

        assertThrows(SecurityException.class,
                     () -> usuarioService.eliminarUsuario(10L, noAdmin));
        verify(usuarioRepository, never()).deleteById(any());
    }

    @Test
    @DisplayName("eliminarUsuario: ADMIN elimina correctamente")
    void eliminarUsuario_Admin() {
        Usuario admin = new Usuario();
        admin.setRol(RolUsuario.ADMIN);

        usuarioService.eliminarUsuario(15L, admin);
        verify(usuarioRepository).deleteById(15L);
    }

    @Test
    @DisplayName("buscarPorId: delega a repository.findById")
    void buscarPorId_DevuelveOptional() {
        Usuario u = new Usuario();
        u.setId(20L);
        when(usuarioRepository.findById(20L)).thenReturn(Optional.of(u));

        Optional<Usuario> opt = usuarioService.buscarPorId(20L);
        assertThat(opt).contains(u);
        verify(usuarioRepository).findById(20L);
    }

    @Test
    @DisplayName("buscarPorEmail: delega a repository.findByEmail")
    void buscarPorEmail_DevuelveOptional() {
        Usuario u = new Usuario();
        u.setEmail("e@ej.com");
        when(usuarioRepository.findByEmail("e@ej.com")).thenReturn(Optional.of(u));

        Optional<Usuario> opt = usuarioService.buscarPorEmail("e@ej.com");
        assertThat(opt).contains(u);
        verify(usuarioRepository).findByEmail("e@ej.com");
    }

    @Test
    @DisplayName("actualizarUsuario: si quien llama no es ADMIN lanza SecurityException")
    void actualizarUsuario_SinPermiso() {
        Usuario cambios = new Usuario();
        cambios.setNombre("X");
        cambios.setEmail("x@ej.com");

        Usuario noAdmin = new Usuario();
        noAdmin.setRol(RolUsuario.LECTOR);

        assertThrows(SecurityException.class,
                     () -> usuarioService.actualizarUsuario(5L, cambios, noAdmin));
        verify(usuarioRepository, never()).findById(any());
    }

    @Test
    @DisplayName("actualizarUsuario: ADMIN actualiza correctamente")
    void actualizarUsuario_AdminValido() {
        Usuario existente = new Usuario();
        existente.setId(7L);
        existente.setNombre("Viejo");
        existente.setEmail("viejo@ej.com");

        when(usuarioRepository.findById(7L)).thenReturn(Optional.of(existente));
        when(usuarioRepository.save(any(Usuario.class))).thenAnswer(inv -> inv.getArgument(0));

        Usuario cambios = new Usuario();
        cambios.setNombre("Nuevo");
        cambios.setEmail("nuevo@ej.com");

        Usuario admin = new Usuario();
        admin.setRol(RolUsuario.ADMIN);

        Usuario resultado = usuarioService.actualizarUsuario(7L, cambios, admin);
        assertThat(resultado.getNombre()).isEqualTo("Nuevo");
        assertThat(resultado.getEmail()).isEqualTo("nuevo@ej.com");

        verify(usuarioRepository).findById(7L);
        verify(usuarioRepository).save(existente);
    }
}
