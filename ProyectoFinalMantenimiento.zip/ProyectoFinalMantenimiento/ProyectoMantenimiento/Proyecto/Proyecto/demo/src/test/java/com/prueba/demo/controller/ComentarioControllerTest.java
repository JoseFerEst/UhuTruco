package com.prueba.demo.controller;

import com.prueba.demo.model.Articulo;
import com.prueba.demo.model.Comentario;
import com.prueba.demo.model.Usuario;
import com.prueba.demo.repository.ArticuloRepository;
import com.prueba.demo.service.ComentarioService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ComentarioController.class)
class ComentarioControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private ComentarioService comentarioService;

    @MockBean
    private ArticuloRepository articuloRepository;

    private MockHttpSession sessionWithUsuario(Long userId) {
        MockHttpSession session = new MockHttpSession();
        Usuario u = new Usuario();
        u.setId(userId);
        session.setAttribute("usuario", u);
        return session;
    }

    @Test
    @DisplayName("POST /comentarios/crear/{articuloId} con comentarios activos → redirige y crea")
    void crearComentario_Correcto() throws Exception {
        Long articuloId = 5L;
        MockHttpSession session = sessionWithUsuario(42L);

        // Mock del artículo con comentarios activos
        Articulo articulo = new Articulo();
        articulo.setId(articuloId);
        articulo.setComentariosActivos(true);
        when(articuloRepository.findById(articuloId)).thenReturn(Optional.of(articulo));

        mvc.perform(post("/comentarios/crear/5")
                .param("contenido", "comentario de prueba")
                .session(session))
           .andExpect(status().is3xxRedirection())
           .andExpect(redirectedUrl("/articulos/Ver/5"));

        ArgumentCaptor<Comentario> captorComentario = ArgumentCaptor.forClass(Comentario.class);
        ArgumentCaptor<Usuario> captorUsuario = ArgumentCaptor.forClass(Usuario.class);
        verify(comentarioService, times(1))
            .crearComentario(captorComentario.capture(), captorUsuario.capture(), eq(5L));

        assertThat(captorComentario.getValue()).isNotNull();
        assertThat(captorUsuario.getValue().getId()).isEqualTo(42L);
    }

    @Test
    @DisplayName("POST /comentarios/eliminar/{id} → elimina comentario y redirige al artículo")
    void eliminarComentario_Correcto() throws Exception {
        MockHttpSession session = sessionWithUsuario(99L);

        mvc.perform(post("/comentarios/eliminar/7")
                .param("articuloId", "5")
                .session(session))
           .andExpect(status().is3xxRedirection())
           .andExpect(redirectedUrl("/articulos/Ver/5"));

        ArgumentCaptor<Long> captorId = ArgumentCaptor.forClass(Long.class);
        ArgumentCaptor<Usuario> captorUsuario = ArgumentCaptor.forClass(Usuario.class);
        verify(comentarioService, times(1))
            .eliminarComentario(captorId.capture(), captorUsuario.capture());

        assertThat(captorId.getValue()).isEqualTo(7L);
        assertThat(captorUsuario.getValue().getId()).isEqualTo(99L);
    }
}
