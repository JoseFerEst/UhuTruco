package com.prueba.demo.controller;

import com.prueba.demo.model.Categoria;
import com.prueba.demo.model.RolUsuario;
import com.prueba.demo.model.Usuario;
import com.prueba.demo.repository.CategoriaRepository;
import com.prueba.demo.service.CategoriaService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(CategoriaController.class)
class CategoriaControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private CategoriaService categoriaService;

    @MockBean
    private CategoriaRepository categoriaRepository;

    private MockHttpSession sessionWith(RolUsuario rol, Long userId) {
        MockHttpSession session = new MockHttpSession();
        Usuario u = new Usuario();
        u.setId(userId);
        u.setRol(rol);
        session.setAttribute("usuario", u);
        return session;
    }

    @Test
    @DisplayName("GET /categorias → modelo contiene lista de categorías")
    void listarCategorias_SoloModelo() throws Exception {
        Categoria c1 = new Categoria();
        c1.setId(1L);
        c1.setNombre("C1");
        when(categoriaService.listarTodas()).thenReturn(Arrays.asList(c1));

        mvc.perform(get("/categorias"))
           .andExpect(status().isOk())
           .andExpect(model().attributeExists("categorias"))
           .andExpect(model().attribute("categorias", hasSize(1)))
           .andExpect(model().attribute("categorias", hasItem(
               allOf(
                   hasProperty("id", is(1L)),
                   hasProperty("nombre", is("C1"))
               )
           )));

        verify(categoriaService).listarTodas();
    }

    @Test
    @DisplayName("GET /categorias/nueva → no ADMIN redirige /categorias")
    void formularioNueva_NoAdmin() throws Exception {
        mvc.perform(get("/categorias/nueva")
                .session(sessionWith(RolUsuario.REDACTOR, 2L)))
           .andExpect(status().is3xxRedirection())
           .andExpect(redirectedUrl("/categorias"));
    }

    @Test
    @DisplayName("GET /categorias/nueva → ADMIN recibe nuevo modelo categoría")
    void formularioNueva_Admin() throws Exception {
        mvc.perform(get("/categorias/nueva")
                .session(sessionWith(RolUsuario.ADMIN, 1L)))
           .andExpect(status().isOk())
           .andExpect(model().attributeExists("categoria"))
           .andExpect(model().attribute("categoria", hasProperty("id", nullValue())))
           .andExpect(model().attribute("categoria", hasProperty("nombre", nullValue())));
    }

    @Test
    @DisplayName("POST /categorias/guardar → no ADMIN redirige /categorias")
    void guardar_NoAdmin() throws Exception {
        mvc.perform(post("/categorias/guardar")
                .param("nombre", "Nueva")
                .param("descripcion", "Desc")
                .session(sessionWith(RolUsuario.LECTOR, 3L)))
           .andExpect(status().is3xxRedirection())
           .andExpect(redirectedUrl("/categorias"));

        verifyNoInteractions(categoriaService);
    }

    @Test
    @DisplayName("POST /categorias/guardar → ADMIN crea y redirige /categorias")
    void guardar_Admin() throws Exception {
        mvc.perform(post("/categorias/guardar")
                .param("nombre", "Nueva")
                .param("descripcion", "Desc")
                .session(sessionWith(RolUsuario.ADMIN, 1L)))
           .andExpect(status().is3xxRedirection())
           .andExpect(redirectedUrl("/categorias"));

        verify(categoriaService).crearCategoria(argThat(c ->
            "Nueva".equals(c.getNombre()) &&
            "Desc".equals(c.getDescripcion())
        ));
    }

    @Test
    @DisplayName("GET /categorias/eliminar/{id} → no ADMIN redirige /categorias")
    void eliminar_NoAdmin() throws Exception {
        mvc.perform(get("/categorias/eliminar/5")
                .session(sessionWith(RolUsuario.REDACTOR, 2L)))
           .andExpect(status().is3xxRedirection())
           .andExpect(redirectedUrl("/categorias"));

        verifyNoInteractions(categoriaRepository);
    }

    @Test
    @DisplayName("GET /categorias/eliminar/{id} → ADMIN elimina y redirige /categorias")
    void eliminar_Admin() throws Exception {
        mvc.perform(get("/categorias/eliminar/5")
                .session(sessionWith(RolUsuario.ADMIN, 1L)))
           .andExpect(status().is3xxRedirection())
           .andExpect(redirectedUrl("/categorias"));

        verify(categoriaRepository).deleteById(5L);
    }

    @Test
    @DisplayName("GET /categorias/editar/{id} → carga categoría en modelo")
    void mostrarFormularioEditar() throws Exception {
        Categoria existente = new Categoria();
        existente.setId(7L);
        existente.setNombre("Existente");
        existente.setDescripcion("DescExist");
        when(categoriaRepository.findById(7L)).thenReturn(Optional.of(existente));

        mvc.perform(get("/categorias/editar/7"))
           .andExpect(status().isOk())
           .andExpect(model().attribute("categoria", hasProperty("id", is(7L))))
           .andExpect(model().attribute("categoria", hasProperty("nombre", is("Existente"))))
           .andExpect(model().attribute("categoria", hasProperty("descripcion", is("DescExist"))));

        verify(categoriaRepository).findById(7L);
    }

    @Test
    @DisplayName("POST /categorias/editarC/{id} → no ADMIN redirige /categorias")
    void editar_NoAdmin() throws Exception {
        mvc.perform(post("/categorias/editarC/7")
                .param("nombre", "X")
                .param("descripcion", "Y")
                .session(sessionWith(RolUsuario.REDACTOR, 2L)))
           .andExpect(status().is3xxRedirection())
           .andExpect(redirectedUrl("/categorias"));

        verifyNoInteractions(categoriaRepository);
    }

    @Test
    @DisplayName("POST /categorias/editarC/{id} → ADMIN edita y redirige /categorias")
    void editar_Admin() throws Exception {
        Categoria existente = new Categoria();
        existente.setId(7L);
        existente.setNombre("Old");
        existente.setDescripcion("OldDesc");
        when(categoriaRepository.findById(7L)).thenReturn(Optional.of(existente));

        mvc.perform(post("/categorias/editarC/7")
                .param("nombre", "Nuevo")
                .param("descripcion", "NuevaDesc")
                .session(sessionWith(RolUsuario.ADMIN, 1L)))
           .andExpect(status().is3xxRedirection())
           .andExpect(redirectedUrl("/categorias"));

        // Después de la llamada, el repositorio debió haber guardado los cambios
        verify(categoriaRepository).findById(7L);
        verify(categoriaRepository).save(argThat(c ->
            c.getId().equals(7L) &&
            "Nuevo".equals(c.getNombre()) &&
            "NuevaDesc".equals(c.getDescripcion())
        ));
    }
}
