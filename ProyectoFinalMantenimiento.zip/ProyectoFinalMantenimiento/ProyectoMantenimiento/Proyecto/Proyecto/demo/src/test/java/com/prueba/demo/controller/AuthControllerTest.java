package com.prueba.demo.controller;

import com.prueba.demo.model.RolUsuario;
import com.prueba.demo.model.Usuario;
import com.prueba.demo.service.UsuarioService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.web.servlet.MockMvc;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasProperty;
import static org.hamcrest.Matchers.is;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(AuthController.class)
class AuthControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private UsuarioService usuarioService;

    @Test
    @DisplayName("GET /auth/registro → modelo con usuario.rol = LECTOR")
    void mostrarFormularioRegistro_SoloModelo() throws Exception {
        mvc.perform(get("/auth/registro"))
           .andExpect(status().isOk())
           .andExpect(model().attributeExists("usuario"))
           .andExpect(model().attribute("usuario", hasProperty("rol", is(RolUsuario.LECTOR))));
    }

    @Test
    @DisplayName("POST /auth/registro → registra Usuario y redirige a /")
    void registrarLector_SinVista() throws Exception {
        mvc.perform(post("/auth/registro")
                .param("nombre", "usuarioTest")
                .param("password", "pass123")
                .param("email", "test@example.com"))
           .andExpect(status().is3xxRedirection())
           .andExpect(redirectedUrl("/"));

        // Capturamos el Usuario enviado al servicio:
        ArgumentCaptor<Usuario> captor = ArgumentCaptor.forClass(Usuario.class);
        verify(usuarioService, times(1)).registrarUsuario(captor.capture());

        Usuario enviado = captor.getValue();
        assertThat(enviado.getNombre()).isEqualTo("usuarioTest");
        assertThat(enviado.getPassword()).isEqualTo("pass123");
        assertThat(enviado.getEmail()).isEqualTo("test@example.com");
        // El controlador forzó rol = LECTOR:
        assertThat(enviado.getRol()).isEqualTo(RolUsuario.LECTOR);
    }

    
}
