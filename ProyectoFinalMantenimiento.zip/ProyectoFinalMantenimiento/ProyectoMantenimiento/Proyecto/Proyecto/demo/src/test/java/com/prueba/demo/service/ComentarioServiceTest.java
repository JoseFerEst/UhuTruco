package com.prueba.demo.service;

import com.prueba.demo.model.Articulo;
import com.prueba.demo.model.Comentario;
import com.prueba.demo.model.RolUsuario;
import com.prueba.demo.model.Usuario;
import com.prueba.demo.repository.ArticuloRepository;
import com.prueba.demo.repository.ComentarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

class ComentarioServiceTest {
	
	@MockBean
    private ComentarioService comentarioService;
    
	@MockBean
	private ComentarioRepository comentarioRepository;
    
	@MockBean
	private ArticuloRepository articuloRepository;

    @BeforeEach
    void setUp() {
        comentarioRepository = mock(ComentarioRepository.class);
        articuloRepository = mock(ArticuloRepository.class);
        comentarioService = new ComentarioService();
        // Inyectar mocks en campos privados
        ReflectionTestUtils.setField(comentarioService, "comentarioRepository", comentarioRepository);
        ReflectionTestUtils.setField(comentarioService, "articuloRepository", articuloRepository);
    }

    @Test
    @DisplayName("eliminarComentario: comentario no existe lanza NoSuchElementException")
    void eliminarComentario_NoExiste() {
        when(comentarioRepository.findById(1L)).thenReturn(Optional.empty());
        Usuario u = new Usuario();
        u.setId(5L);
        u.setRol(RolUsuario.ADMIN);

        assertThrows(java.util.NoSuchElementException.class,
                     () -> comentarioService.eliminarComentario(1L, u));
    }

    @Test
    @DisplayName("eliminarComentario: usuario sin permiso lanza SecurityException")
    void eliminarComentario_SinPermiso() {
        // Comentario con autor distinto y perteneciente a artículo cuyo autor es otro usuario
        Usuario autorArticulo = new Usuario();
        autorArticulo.setId(2L);
        autorArticulo.setRol(RolUsuario.REDACTOR);

        Articulo articulo = new Articulo();
        articulo.setId(10L);
        articulo.setAutor(autorArticulo);

        Comentario comentario = new Comentario();
        comentario.setId(3L);
        comentario.setAutor(new Usuario() {{
            setId(4L);
            setRol(RolUsuario.REDACTOR);
        }});
        comentario.setArticulo(articulo);

        when(comentarioRepository.findById(3L)).thenReturn(Optional.of(comentario));

        // Usuario distinto al autor de artículo y distinto al autor de comentario
        Usuario otro = new Usuario();
        otro.setId(6L);
        otro.setRol(RolUsuario.REDACTOR);

        assertThrows(SecurityException.class,
                     () -> comentarioService.eliminarComentario(3L, otro));
        verify(comentarioRepository).findById(3L);
        verify(comentarioRepository, never()).delete(any());
    }

    @Test
    @DisplayName("eliminarComentario: autor del comentario elimina sin error")
    void eliminarComentario_AutorComentario() {
        Usuario autorArticulo = new Usuario();
        autorArticulo.setId(2L);
        autorArticulo.setRol(RolUsuario.REDACTOR);

        Articulo articulo = new Articulo();
        articulo.setId(10L);
        articulo.setAutor(autorArticulo);

        Usuario autorComentario = new Usuario();
        autorComentario.setId(4L);
        autorComentario.setRol(RolUsuario.REDACTOR);

        Comentario comentario = new Comentario();
        comentario.setId(3L);
        comentario.setAutor(autorComentario);
        comentario.setArticulo(articulo);

        when(comentarioRepository.findById(3L)).thenReturn(Optional.of(comentario));

        // El mismo autor del comentario
        comentarioService.eliminarComentario(3L, autorComentario);
        verify(comentarioRepository).delete(comentario);
    }

    @Test
    @DisplayName("eliminarComentario: autor del artículo elimina sin error")
    void eliminarComentario_AutorArticulo() {
        Usuario autorArticulo = new Usuario();
        autorArticulo.setId(2L);
        autorArticulo.setRol(RolUsuario.REDACTOR);

        Articulo articulo = new Articulo();
        articulo.setId(10L);
        articulo.setAutor(autorArticulo);

        Comentario comentario = new Comentario();
        comentario.setId(3L);
        comentario.setAutor(new Usuario() {{
            setId(4L);
            setRol(RolUsuario.REDACTOR);
        }});
        comentario.setArticulo(articulo);

        when(comentarioRepository.findById(3L)).thenReturn(Optional.of(comentario));

        comentarioService.eliminarComentario(3L, autorArticulo);
        verify(comentarioRepository).delete(comentario);
    }

    @Test
    @DisplayName("eliminarComentario: ADMIN elimina sin error")
    void eliminarComentario_Admin() {
        Usuario autorArticulo = new Usuario();
        autorArticulo.setId(2L);
        autorArticulo.setRol(RolUsuario.REDACTOR);

        Articulo articulo = new Articulo();
        articulo.setId(10L);
        articulo.setAutor(autorArticulo);

        Comentario comentario = new Comentario();
        comentario.setId(3L);
        comentario.setAutor(new Usuario() {{
            setId(4L);
            setRol(RolUsuario.REDACTOR);
        }});
        comentario.setArticulo(articulo);

        when(comentarioRepository.findById(3L)).thenReturn(Optional.of(comentario));

        Usuario admin = new Usuario();
        admin.setId(1L);
        admin.setRol(RolUsuario.ADMIN);

        comentarioService.eliminarComentario(3L, admin);
        verify(comentarioRepository).delete(comentario);
    }

    @Test
    @DisplayName("crearComentario: artículo no existe lanza IllegalArgumentException")
    void crearComentario_ArticuloNoExiste() {
        when(articuloRepository.findById(5L)).thenReturn(Optional.empty());
        Usuario u = new Usuario();
        u.setId(7L);
        u.setRol(RolUsuario.LECTOR);

        assertThrows(IllegalArgumentException.class,
                     () -> comentarioService.crearComentario(new Comentario(), u, 5L));
        verify(articuloRepository).findById(5L);
    }

    @Test
    @DisplayName("crearComentario: comentarios desactivados lanza IllegalStateException")
    void crearComentario_ComentariosDesactivados() {
        Articulo articulo = new Articulo();
        Usuario redactor = new Usuario() {{
            setId(2L);
            setRol(RolUsuario.REDACTOR);
        }};
        articulo.setId(5L);
        articulo.setAutor(redactor);
        articulo.setComentariosActivos(false);

        

        when(articuloRepository.findById(5L)).thenReturn(Optional.of(articulo));

        Usuario u = new Usuario();
        u.setId(7L);
        u.setRol(RolUsuario.LECTOR);

        assertThrows(IllegalStateException.class,
                     () -> comentarioService.crearComentario(new Comentario(), u, 5L));
        verify(articuloRepository).findById(5L);
        verifyNoInteractions(comentarioRepository);
    }

    @Test
    @DisplayName("crearComentario: guarda correctamente y asigna autor y artículo")
    void crearComentario_Valido() {
    	Articulo articulo = new Articulo();
        Usuario redactor = new Usuario() {{
            setId(2L);
            setRol(RolUsuario.REDACTOR);
        }};
        articulo.setId(5L);
        articulo.setAutor(redactor);
        articulo.setComentariosActivos(true);

        when(articuloRepository.findById(5L)).thenReturn(Optional.of(articulo));
        when(comentarioRepository.save(any(Comentario.class))).thenAnswer(inv -> inv.getArgument(0));

        Usuario u = new Usuario();
        u.setId(7L);
        u.setRol(RolUsuario.LECTOR);

        Comentario comentario = new Comentario();
        comentarioService.crearComentario(comentario, u, 5L);

        assertThat(comentario.getAutor().getId()).isEqualTo(7L);
        assertThat(comentario.getArticulo().getId()).isEqualTo(5L);
        verify(comentarioRepository).save(comentario);
    }

    @Test
    @DisplayName("toggleComentariosActivos: artículo no existe lanza NoSuchElementException")
    void toggleComentariosActivos_ArticuloNoExiste() {
        when(articuloRepository.findById(9L)).thenReturn(Optional.empty());
        Usuario u = new Usuario();
        u.setId(3L);
        u.setRol(RolUsuario.ADMIN);

 
        verify(articuloRepository).findById(9L);
    }

    @Test
    @DisplayName("toggleComentariosActivos: usuario sin permiso lanza SecurityException")
    void toggleComentariosActivos_SinPermiso() {
    	Articulo articulo = new Articulo();
        Usuario redactor = new Usuario() {{
            setId(2L);
            setRol(RolUsuario.REDACTOR);
        }};
        articulo.setId(5L);
        articulo.setAutor(redactor);
        articulo.setComentariosActivos(false);

        when(articuloRepository.findById(9L)).thenReturn(Optional.of(articulo));

        // Usuario que no es autor ni admin
        Usuario otro = new Usuario();
        otro.setId(5L);
        otro.setRol(RolUsuario.REDACTOR);

      
        verify(articuloRepository).findById(9L);
        verify(articuloRepository, never()).save(any());
    }

    @Test
    @DisplayName("toggleComentariosActivos: autor del artículo modifica correctamente")
    void toggleComentariosActivos_Autor() {
        Usuario autorArticulo = new Usuario();
        autorArticulo.setId(2L);
        autorArticulo.setRol(RolUsuario.REDACTOR);

        // Mock de Articulo
        Articulo articulo = mock(Articulo.class);
        when(articulo.getId()).thenReturn(9L);
        when(articulo.getAutor()).thenReturn(autorArticulo);
        when(articuloRepository.findById(9L)).thenReturn(Optional.of(articulo));
        when(articuloRepository.save(any(Articulo.class))).thenAnswer(inv -> inv.getArgument(0));

        Usuario u = new Usuario();
        u.setId(2L);
        u.setRol(RolUsuario.REDACTOR);
        
        u = autorArticulo;


        // Ahora usamos eq(...) en lugar de literales
        verify(articulo).setComentariosActivos(eq(false));
        verify(articuloRepository).save(articulo);
    }


    @Test
    @DisplayName("toggleComentariosActivos: ADMIN modifica correctamente")
    void toggleComentariosActivos_Admin() {
        Usuario autorArticulo = new Usuario();
        autorArticulo.setId(2L);
        autorArticulo.setRol(RolUsuario.REDACTOR);

        Articulo articulo = mock(Articulo.class);
        when(articulo.getId()).thenReturn(9L);
        when(articulo.getAutor()).thenReturn(autorArticulo);
        when(articuloRepository.findById(9L)).thenReturn(Optional.of(articulo));
        when(articuloRepository.save(any(Articulo.class))).thenAnswer(inv -> inv.getArgument(0));

        Usuario admin = new Usuario();
        admin.setId(1L);
        admin.setRol(RolUsuario.ADMIN);


        verify(articuloRepository).save(articulo);
        
    }
}
