package com.prueba.demo.controller;

import com.prueba.demo.model.RolUsuario;
import com.prueba.demo.model.Usuario;
import com.prueba.demo.repository.CategoriaRepository;
import com.prueba.demo.service.UsuarioService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(LoginController.class)
class LoginControllerTest {

    @Autowired
    private MockMvc mvc;

    @MockBean
    private UsuarioService usuarioService;

    @MockBean
    private CategoriaRepository categoriaRepository;

    @Test
    @DisplayName("POST /login con credenciales válidas ADMIN → redirect /usuarios/home")
    void loginAdmin_Valido() throws Exception {
        Usuario admin = new Usuario();
        admin.setId(1L);
        admin.setEmail("admin@example.com");
        admin.setPassword("secret");
        admin.setRol(RolUsuario.ADMIN);

        when(usuarioService.buscarPorEmail("admin@example.com"))
            .thenReturn(Optional.of(admin));
        when(categoriaRepository.findAll()).thenReturn(java.util.Collections.emptyList());

        mvc.perform(post("/login")
                .param("email", "admin@example.com")
                .param("password", "secret")
                .session(new MockHttpSession()))
           .andExpect(status().is3xxRedirection())
           .andExpect(redirectedUrl("/usuarios/home"));

        verify(usuarioService).buscarPorEmail("admin@example.com");
    }

    @Test
    @DisplayName("POST /login con credenciales válidas REDACTOR → redirect /usuarios/home-redactor")
    void loginRedactor_Valido() throws Exception {
        Usuario redactor = new Usuario();
        redactor.setId(2L);
        redactor.setEmail("editor@example.com");
        redactor.setPassword("editpass");
        redactor.setRol(RolUsuario.REDACTOR);

        when(usuarioService.buscarPorEmail("editor@example.com"))
            .thenReturn(Optional.of(redactor));
        when(categoriaRepository.findAll()).thenReturn(java.util.Collections.emptyList());

        mvc.perform(post("/login")
                .param("email", "editor@example.com")
                .param("password", "editpass")
                .session(new MockHttpSession()))
           .andExpect(status().is3xxRedirection())
           .andExpect(redirectedUrl("/usuarios/home-redactor"));

        verify(usuarioService).buscarPorEmail("editor@example.com");
    }

    @Test
    @DisplayName("POST /login con usuario sin rol → redirect a /")
    void loginSinRol_Redirect() throws Exception {
        Usuario sinRol = new Usuario();
        sinRol.setId(3L);
        sinRol.setEmail("norole@example.com");
        sinRol.setPassword("nopass");
        sinRol.setRol(null);

        when(usuarioService.buscarPorEmail("norole@example.com"))
            .thenReturn(Optional.of(sinRol));

        mvc.perform(post("/login")
                .param("email", "norole@example.com")
                .param("password", "nopass")
                .session(new MockHttpSession()))
           .andExpect(status().is3xxRedirection())
           .andExpect(redirectedUrl("/"));

        verify(usuarioService).buscarPorEmail("norole@example.com");
    }

    @Test
    @DisplayName("POST /login con rol LECTOR → redirect /articulos")
    void loginLector_RedirectArticulos() throws Exception {
        Usuario lector = new Usuario();
        lector.setId(4L);
        lector.setEmail("lector@example.com");
        lector.setPassword("lector123");
        lector.setRol(RolUsuario.LECTOR);

        when(usuarioService.buscarPorEmail("lector@example.com"))
            .thenReturn(Optional.of(lector));
        when(categoriaRepository.findAll()).thenReturn(java.util.Collections.emptyList());

        mvc.perform(post("/login")
                .param("email", "lector@example.com")
                .param("password", "lector123")
                .session(new MockHttpSession()))
           .andExpect(status().is3xxRedirection())
           .andExpect(redirectedUrl("/articulos"));

        verify(usuarioService).buscarPorEmail("lector@example.com");
    }

    @Test
    @DisplayName("POST /login con email inexistente → redirect a /")
    void loginEmailInexistente_Redirect() throws Exception {
        when(usuarioService.buscarPorEmail("noexiste@example.com"))
            .thenReturn(Optional.empty());

        mvc.perform(post("/login")
                .param("email", "noexiste@example.com")
                .param("password", "loquesea")
                .session(new MockHttpSession()))
           .andExpect(status().is3xxRedirection())
           .andExpect(redirectedUrl("/"));

        verify(usuarioService).buscarPorEmail("noexiste@example.com");
    }

    @Test
    @DisplayName("POST /login con contraseña incorrecta → redirect a /")
    void loginPasswordIncorrecta_Redirect() throws Exception {
        Usuario existe = new Usuario();
        existe.setId(5L);
        existe.setEmail("user@example.com");
        existe.setPassword("correcta");
        existe.setRol(RolUsuario.ADMIN);

        when(usuarioService.buscarPorEmail("user@example.com"))
            .thenReturn(Optional.of(existe));

        mvc.perform(post("/login")
                .param("email", "user@example.com")
                .param("password", "incorrecta")
                .session(new MockHttpSession()))
           .andExpect(status().is3xxRedirection())
           .andExpect(redirectedUrl("/"));

        verify(usuarioService).buscarPorEmail("user@example.com");
    }

    @Test
    @DisplayName("GET /logout → invalida sesión y redirige a /")
    void logout_Redirecciona() throws Exception {
        MockHttpSession session = new MockHttpSession();
        Usuario usuario = new Usuario();
        usuario.setId(6L);
        usuario.setEmail("logout@example.com");
        usuario.setPassword("pass");
        usuario.setRol(RolUsuario.ADMIN);
        session.setAttribute("usuario", usuario);

        mvc.perform(get("/logout").session(session))
           .andExpect(status().is3xxRedirection())
           .andExpect(redirectedUrl("/"));
    }
}
