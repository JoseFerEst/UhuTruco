package com.prueba.demo.controller;

import com.prueba.demo.model.Articulo;
import com.prueba.demo.model.Categoria;
import com.prueba.demo.model.RolUsuario;
import com.prueba.demo.model.Usuario;
import com.prueba.demo.repository.ArticuloRepository;
import com.prueba.demo.repository.CategoriaRepository;
import com.prueba.demo.service.ArticuloService;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.mock.web.MockHttpSession;
import org.springframework.test.web.servlet.MockMvc;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Optional;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(ArticuloController.class)
class ArticuloControllerTest {

    @Autowired
    private MockMvc mvc;

    
    @MockBean
    private ArticuloRepository articuloRepository;

    @MockBean
    private CategoriaRepository categoriaRepository;

    @MockBean
    private ArticuloService articuloService;


    private MockHttpSession sessionWith(RolUsuario rol, Long userId) {
        MockHttpSession session = new MockHttpSession();
        Usuario u = new Usuario();
        u.setId(userId);
        u.setRol(rol);
        session.setAttribute("usuario", u);
        return session;
    }

    private Articulo ejemploArticuloConDatos() {
        Articulo a = new Articulo();
        a.setId(1L);

        // Le ponemos un autor con nombre
        Usuario autor = new Usuario();
        autor.setId(50L);
        autor.setNombre("AutorTest");
        a.setAutor(autor);

        // Le ponemos una categoría con nombre
        Categoria cat = new Categoria();
        cat.setId(10L);
        cat.setNombre("CategoríaTest");
        a.setCategoria(cat);

        // Fecha de publicación para el detalle
        a.setFechaPublicacion(LocalDateTime.now());
        return a;
    }

    @Test
    @DisplayName("GET /articulos → lista-articulos")
    void listarArticulos() throws Exception {
        Articulo prueba = ejemploArticuloConDatos();
        when(articuloRepository.findAll()).thenReturn(Arrays.asList(prueba));

        mvc.perform(get("/articulos"))
           .andExpect(status().isOk())
           .andExpect(model().attributeExists("articulos"))
           .andExpect(view().name("lista-articulos"));

        verify(articuloRepository).findAll();
    }

    @Test
    @DisplayName("GET /articulos/admin → lista-articulos-admin")
    void listaAdmin() throws Exception {
        Articulo prueba = ejemploArticuloConDatos();
        when(articuloRepository.findAll()).thenReturn(Arrays.asList(prueba));

        mvc.perform(get("/articulos/admin"))
           .andExpect(status().isOk())
           .andExpect(model().attributeExists("articulos"))
           .andExpect(view().name("lista-articulos-admin"));

        verify(articuloRepository).findAll();
    }

    @Test
    @DisplayName("GET /articulos/redactor → lista-articulos-redactor")
    void listaRedactor() throws Exception {
        Articulo prueba = ejemploArticuloConDatos();
        when(articuloRepository.findAll()).thenReturn(Arrays.asList(prueba));

        mvc.perform(get("/articulos/redactor"))
           .andExpect(status().isOk())
           .andExpect(model().attributeExists("articulos"))
           .andExpect(view().name("lista-articulos-redactor"));

        verify(articuloRepository).findAll();
    }

    @Test
    @DisplayName("GET /articulos/Ver/{id} → VerArticulos-redactor (según rol)")
    void verArticuloConRol() throws Exception {
        Articulo prueba = ejemploArticuloConDatos();
        when(articuloRepository.findById(1L)).thenReturn(Optional.of(prueba));
        when(categoriaRepository.findAll()).thenReturn(Arrays.asList(new Categoria()));

        MockHttpSession session = sessionWith(RolUsuario.REDACTOR, 50L);

        mvc.perform(get("/articulos/Ver/1").session(session))
           .andExpect(status().isOk())
           .andExpect(model().attributeExists("articulo"))
           .andExpect(model().attributeExists("estado"))
           .andExpect(model().attributeExists("fechaFormateada"))
           .andExpect(model().attributeExists("categorias"))
           .andExpect(view().name("VerArticulos-redactor"));
    }


    @Test
    @DisplayName("GET /articulos/nuevo → formulario-articulo")
    void nuevoFormulario() throws Exception {
        when(categoriaRepository.findAll()).thenReturn(Arrays.asList(new Categoria()));

        mvc.perform(get("/articulos/nuevo"))
           .andExpect(status().isOk())
           .andExpect(model().attributeExists("articulo"))
           .andExpect(model().attributeExists("categorias"))
           .andExpect(view().name("formulario-articulo"));

        verify(categoriaRepository).findAll();
    }

    @Test
    @DisplayName("POST /articulos/guardar → ADMIN redirige /articulos/admin")
    void guardarArticulo_Admin() throws Exception {
        MockHttpSession admin = sessionWith(RolUsuario.ADMIN, 1L);

        mvc.perform(post("/articulos/guardar")
                .session(admin)
                .contentType("application/x-www-form-urlencoded")
                .param("titulo", "Título de prueba")
                .param("cuerpo", "Cuerpo de prueba"))
           .andExpect(status().is3xxRedirection())
           .andExpect(redirectedUrl("/articulos/admin"));

        verifyNoInteractions(articuloService);
    }

    @Test
    @DisplayName("POST /articulos/guardar → REDACTOR guarda y redirige /articulos/redactor")
    void guardarArticulo_Redactor() throws Exception {
        MockHttpSession redactor = sessionWith(RolUsuario.REDACTOR, 2L);
        doNothing().when(articuloService).guardarArticulo(any(), any());

        mvc.perform(post("/articulos/guardar")
                .session(redactor)
                .contentType("application/x-www-form-urlencoded")
                .param("titulo", "Título de prueba")
                .param("cuerpo", "Cuerpo de prueba"))
           .andExpect(status().is3xxRedirection())
           .andExpect(redirectedUrl("/articulos/redactor"));

        verify(articuloService).guardarArticulo(any(), any());
    }

    @Test
    @DisplayName("GET /articulos/editar/{id} → formulario-articulo-edit")
    void editarFormulario() throws Exception {
        Articulo prueba = ejemploArticuloConDatos();
        when(articuloRepository.findById(7L)).thenReturn(Optional.of(prueba));
        when(categoriaRepository.findAll()).thenReturn(Arrays.asList(new Categoria()));

        mvc.perform(get("/articulos/editar/7"))
           .andExpect(status().isOk())
           .andExpect(model().attribute("articulo", prueba))
           .andExpect(model().attributeExists("categorias"))
           .andExpect(view().name("formulario-articulo-edit"));

        verify(articuloRepository).findById(7L);
        verify(categoriaRepository).findAll();
    }

    @Test
    @DisplayName("POST /articulos/editarA/{id} → ADMIN redirige /articulos/admin")
    void editarArticulo_Admin() throws Exception {
        Articulo existente = ejemploArticuloConDatos();
        when(articuloRepository.findById(9L)).thenReturn(Optional.of(existente));
        doNothing().when(articuloService).guardarArticulo(any(), any());

        MockHttpSession admin = sessionWith(RolUsuario.ADMIN, 100L);

        mvc.perform(post("/articulos/editarA/9")
                .session(admin)
                .contentType("application/x-www-form-urlencoded")
                .param("id", "9")
                .param("titulo", "Nuevo título")
                .param("cuerpo", "Nuevo cuerpo"))
           .andExpect(status().is3xxRedirection())
           .andExpect(redirectedUrl("/articulos/admin"));

        verify(articuloService).guardarArticulo(any(), any());
    }

    @Test
    @DisplayName("GET /articulos/eliminar/{id} → flujos de rol")
    void eliminarArticulo_Roles() throws Exception {
        Articulo prueba = ejemploArticuloConDatos();
        when(articuloRepository.findById(3L)).thenReturn(Optional.of(prueba));

        // LECTOR no elimina y redirige /articulos
        MockHttpSession lector = sessionWith(RolUsuario.LECTOR, 99L);
        mvc.perform(get("/articulos/eliminar/3").session(lector))
           .andExpect(status().is3xxRedirection())
           .andExpect(redirectedUrl("/articulos"));

        // REDACTOR elimina y redirige /articulos/redactor
        MockHttpSession autor = sessionWith(RolUsuario.REDACTOR, 50L);
        mvc.perform(get("/articulos/eliminar/3").session(autor))
           .andExpect(status().is3xxRedirection())
           .andExpect(redirectedUrl("/articulos/redactor"));

        verify(articuloRepository).deleteById(3L);
    }
}
