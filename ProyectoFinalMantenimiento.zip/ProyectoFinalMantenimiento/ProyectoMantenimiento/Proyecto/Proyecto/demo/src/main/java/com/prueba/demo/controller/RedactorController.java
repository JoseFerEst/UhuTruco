package com.prueba.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.prueba.demo.model.RolUsuario;
import com.prueba.demo.model.Usuario;
import com.prueba.demo.service.RedactorService;

@Controller
@RequestMapping("/auth/gestion-redactor")
public class RedactorController {
    
    @Autowired
    private RedactorService redactorService;
    
    @GetMapping
    public String listRedactores(Model model) {
        model.addAttribute("redactores", redactorService.findAllRedactores());
        return "gestion-redactor";
    }
    @GetMapping("/nuevo")
    public String showNewRedactorForm(Model model) {
        Usuario redactor = new Usuario();
        redactor.setRol(RolUsuario.REDACTOR); // Asignar rol por defecto
        model.addAttribute("redactor", redactor);
        // Para mostrar los roles en el formulario (si quieres permitir cambiar el rol)
        model.addAttribute("roles", RolUsuario.values()); 
        return "nuevo-redactor";
    }
    
    @GetMapping("/editar/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        redactorService.findRedactorById(id).ifPresent(redactor -> {
            model.addAttribute("redactor", redactor);
            // Para mostrar los roles en el formulario (si quieres permitir cambiar el rol)
            model.addAttribute("roles", RolUsuario.values()); 
        });
        return "editar-redactor";
    }
    
    @PostMapping("/actualizar")
public String updateRedactor(@ModelAttribute Usuario redactor) {
    Usuario redactorExistente = redactorService.findRedactorById(redactor.getId())
        .orElseThrow(() -> new IllegalArgumentException("Redactor no encontrado"));
    
    // Actualizar solo campos no sensibles
    redactorExistente.setNombre(redactor.getNombre());
    redactorExistente.setEmail(redactor.getEmail());
    redactorExistente.setRol(redactor.getRol());
    
    // Mantener la contraseña original
    redactor.setPassword(redactorExistente.getPassword());
    
    redactorService.updateRedactor(redactorExistente);
    return "redirect:/auth/gestion-redactor";
}
    
    @GetMapping("/eliminar/{id}")
    public String deleteRedactor(@PathVariable Long id) {
        redactorService.deleteRedactor(id);
        return "redirect:/auth/gestion-redactor";
    }

    @PostMapping("/nuevo")
    public String createRedactor(@ModelAttribute Usuario redactor) {
        redactor.setRol(RolUsuario.REDACTOR); // Asignar rol por defecto
        redactorService.createRedactor(redactor);
        return "redirect:/auth/gestion-redactor";

    }
}