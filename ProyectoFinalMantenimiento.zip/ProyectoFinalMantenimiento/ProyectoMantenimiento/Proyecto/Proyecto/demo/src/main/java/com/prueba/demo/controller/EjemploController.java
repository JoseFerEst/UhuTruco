package com.prueba.demo.controller;

import com.prueba.demo.model.Ejemplo;
import com.prueba.demo.repository.EjemploRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/ejemplos")  // Todos los endpoints empiezan con /ejemplos
public class EjemploController {

    @Autowired
    private EjemploRepository ejemploRepository;

    // Listar todos (READ)
    @GetMapping
    public String listarEjemplos(Model model) {
        model.addAttribute("ejemplos", ejemploRepository.findAll());
        return "lista-ejemplos";  // Nombre del archivo HTML (sin extensión)
    }

    // Mostrar formulario de creación (CREATE)
    @GetMapping("/nuevo")
    public String mostrarFormularioNuevo(Model model) {
        model.addAttribute("ejemplo", new Ejemplo());
        return "formulario-ejemplo";
    }

    // Guardar nuevo (CREATE)
    @PostMapping("/guardar")
    public String guardarEjemplo(@ModelAttribute Ejemplo ejemplo) {
        ejemploRepository.save(ejemplo);
        return "redirect:/ejemplos";
    }

    // Mostrar formulario de edición (UPDATE)
    @GetMapping("/editar/{id}")
    public String mostrarFormularioEditar(@PathVariable Long id, Model model) {
        model.addAttribute("ejemplo", ejemploRepository.findById(id).orElseThrow());
        return "formulario-ejemplo";
    }

    // Eliminar (DELETE)
    @GetMapping("/eliminar/{id}")
    public String eliminarEjemplo(@PathVariable Long id) {
        ejemploRepository.deleteById(id);
        return "redirect:/ejemplos";
    }
}