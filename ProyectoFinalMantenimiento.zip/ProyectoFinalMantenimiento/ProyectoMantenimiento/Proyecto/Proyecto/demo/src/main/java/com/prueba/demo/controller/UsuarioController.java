package com.prueba.demo.controller;

import java.util.List;

import jakarta.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import com.prueba.demo.model.RolUsuario;
import com.prueba.demo.model.Usuario;
import com.prueba.demo.service.UsuarioService;

@Controller
@RequestMapping("/usuarios")
public class UsuarioController {

    @Autowired
    private UsuarioService usuarioService;

   @GetMapping("/home")
    public String mostrarHome() {
        return "home"; // esto busca home.html en /templates
    }
    
    @GetMapping("/home-redactor")
    public String mostrarHomeRedactor() {
        return "home-redactor"; // esto busca home-redactor.html en /templates
    }
   
    // Listar redactores (solo admins)
    @GetMapping("/redactores")
    public String listarRedactores(Model model, HttpSession session) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");
        if (usuario == null || !usuario.getRol().equals(RolUsuario.ADMIN)) {
            return "error/403";  // Página de acceso denegado
        }
        List<Usuario> redactores = usuarioService.listarRedactores();
        model.addAttribute("redactores", redactores);
        return "lista-redactores";
    }


    // Mostrar formulario para crear redactor (solo admins)
    @GetMapping("/crear-redactor")
    public String mostrarFormularioCrearRedactor(Model model, HttpSession session) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");
        if (usuario == null || !usuario.getRol().equals(RolUsuario.ADMIN)) {
            return "error/403";
        }
        model.addAttribute("redactor", new Usuario());
        return "formulario-crear-redactor";
    }

    // Procesar creación de redactor
    @PostMapping("/crear-redactor")
    public String crearRedactor(@ModelAttribute Usuario redactor, HttpSession session) {
        Usuario admin = (Usuario) session.getAttribute("usuario");
        if (admin == null || !admin.getRol().equals(RolUsuario.ADMIN)) {
            return "error/403";
        }
        usuarioService.crearRedactor(redactor, admin);
        return "redirect:/usuarios/redactores";
    }

    // Eliminar usuario (solo admins)
    @GetMapping("/eliminar/{id}")
    public String eliminarUsuario(@PathVariable Long id, HttpSession session) {
        Usuario admin = (Usuario) session.getAttribute("usuario");
        if (admin == null || !admin.getRol().equals(RolUsuario.ADMIN)) {
            return "error/403";
        }
        usuarioService.eliminarUsuario(id, admin);
        return "redirect:/usuarios/redactores";
    }

    // Mostrar formulario editar usuario (solo admins)
    @GetMapping("/editar/{id}")
    public String mostrarFormularioEditar(@PathVariable Long id, Model model, HttpSession session) {
        Usuario admin = (Usuario) session.getAttribute("usuario");
        if (admin == null || !admin.getRol().equals(RolUsuario.ADMIN)) {
            return "error/403";
        }
        Usuario usuario = usuarioService.buscarPorId(id).orElseThrow(); // Utiliza un método público del service
        model.addAttribute("usuario", usuario);
        return "formulario-editar-usuario";
    }

    // Procesar edición (solo admins)
    @PostMapping("/editar/{id}")
    public String editarUsuario(@PathVariable Long id, @ModelAttribute Usuario cambios, HttpSession session) {
        Usuario admin = (Usuario) session.getAttribute("usuario");
        if (admin == null || !admin.getRol().equals(RolUsuario.ADMIN)) {
            return "error/403";
        }
        usuarioService.actualizarUsuario(id, cambios, admin);
        return "redirect:/usuarios/redactores";
    }
}
