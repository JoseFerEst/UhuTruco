package com.prueba.demo.repository;

import org.springframework.stereotype.Repository;
import com.prueba.demo.model.Articulo;
import com.prueba.demo.model.Categoria;
import com.prueba.demo.model.Usuario;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

@Repository
public interface ArticuloRepository extends JpaRepository<Articulo, Long>, JpaSpecificationExecutor<Articulo> {
   // Para buscar artículos por título (requisito 6.1)
    @Query("SELECT a FROM Articulo a WHERE a.titulo LIKE %:titulo%")
List<Articulo> findByTituloContaining(@Param("titulo") String titulo);  // Cambiado el nombre   

// Para buscar artículos por autor (requisito 6.2)
List<Articulo> findByAutor(Usuario autor);

// Para buscar artículos por categoría (requisito 5.1)
List<Articulo> findByCategoria(Categoria categoria);

}
