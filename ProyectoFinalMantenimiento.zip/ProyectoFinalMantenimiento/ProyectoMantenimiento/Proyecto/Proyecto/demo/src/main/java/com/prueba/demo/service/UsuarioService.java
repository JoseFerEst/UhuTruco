package com.prueba.demo.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prueba.demo.model.RolUsuario;
import com.prueba.demo.model.Usuario;
import com.prueba.demo.repository.UsuarioRepository;

@Service
public class UsuarioService {
    @Autowired
    private UsuarioRepository usuarioRepository;
    // Método para que un ADMIN cree redactores (ya lo tienes)
    public Usuario crearRedactor(Usuario redactor, Usuario admin) {
        if (!admin.getRol().equals(RolUsuario.ADMIN)) {
            throw new SecurityException("Solo los administradores pueden crear redactores");
        }
        redactor.setRol(RolUsuario.ADMIN);
        return usuarioRepository.save(redactor);
    }

    public List<Usuario> listarRedactores() {
        return usuarioRepository.findByRol(RolUsuario.REDACTOR);
    }

    

    // Registro público (solo para lectores)
    public Usuario registrarLector(Usuario usuario) {
        if (usuarioRepository.existsByEmail(usuario.getEmail())) {
            throw new IllegalArgumentException("El email ya está registrado");
        }
        usuario.setRol(RolUsuario.LECTOR); // Asignar rol automáticamente
        return usuarioRepository.save(usuario);
    }

    // Registro público (solo para redactores)
    public Usuario registrarUsuario(Usuario usuario) {
        if (usuarioRepository.existsByEmail(usuario.getEmail())) {
            throw new IllegalArgumentException("El email ya está registrado");
        }
        usuario.setRol(RolUsuario.LECTOR); // Asignar rol automáticamente
        return usuarioRepository.save(usuario);
    }

    // Registro público (solo para administradores)
    public Usuario registrarAdmin(Usuario usuario) {
        if (usuarioRepository.existsByEmail(usuario.getEmail())) {
            throw new IllegalArgumentException("El email ya está registrado");
        }
        usuario.setRol(RolUsuario.ADMIN); // Asignar rol automáticamente
        return usuarioRepository.save(usuario);
    }


    public Usuario registrarRedactor(Usuario usuario) {
        if (usuarioRepository.existsByEmail(usuario.getEmail())) {
            throw new IllegalArgumentException("El email ya está registrado");
        }
        usuario.setRol(RolUsuario.REDACTOR); // Asignar rol automáticamente
        return usuarioRepository.save(usuario);
    }
    

    public void eliminarUsuario(Long id, Usuario admin) {
        if (!admin.getRol().equals(RolUsuario.ADMIN)) {
            throw new SecurityException("Solo los administradores pueden eliminar usuarios");
        }
        usuarioRepository.deleteById(id);
    }

    

public Optional<Usuario> buscarPorId(Long id) {
    return usuarioRepository.findById(id);
}
public Optional<Usuario> buscarPorEmail(String email) {
    return usuarioRepository.findByEmail(email);
}

//revisar y posiblemente eliminar
    public Usuario actualizarUsuario(Long id, Usuario cambios, Usuario admin) {
    if (!admin.getRol().equals(RolUsuario.ADMIN)) {
        throw new SecurityException("Solo los administradores pueden editar usuarios");
    }
    Usuario usuario = usuarioRepository.findById(id).orElseThrow();
    usuario.setNombre(cambios.getNombre());
    usuario.setEmail(cambios.getEmail());
    // No actualices el rol directamente aquí (puede ser peligroso)
    return usuarioRepository.save(usuario);
}


}