package com.prueba.demo.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.prueba.demo.model.Articulo;
import com.prueba.demo.model.Categoria;
import com.prueba.demo.model.RolUsuario;
import com.prueba.demo.model.Usuario;
import com.prueba.demo.repository.ArticuloRepository;
import com.prueba.demo.repository.CategoriaRepository;
import com.prueba.demo.service.ArticuloService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/articulos")
public class ArticuloController {
    
    @Autowired
    private ArticuloRepository articuloRepository;

    @Autowired
    private CategoriaRepository categoriaRepository; // Si necesitas categorías

    @Autowired
    private ArticuloService articuloService;

    private boolean estado=true;

    @GetMapping
    public String listarArticulos(Model model) {
        model.addAttribute("articulos", articuloRepository.findAll());
        return "lista-articulos";
    }

    @GetMapping("/admin")
    public String listaAdmin(Model model) {
        model.addAttribute("articulos", articuloRepository.findAll());
        return "lista-articulos-admin"; // Vista solo para admin
    }

    @GetMapping("/redactor")
    public String listaRedactor(Model model) {
        model.addAttribute("articulos", articuloRepository.findAll());
        return "lista-articulos-redactor"; // Vista solo para redactor
    }


   
    @GetMapping("/Ver/{id}")
    public String verArticulo(@PathVariable Long id, Model model, HttpSession session) {
       
    
   Articulo aux = articuloRepository.findById(id).orElseThrow();
        model.addAttribute("estado", estado);
        model.addAttribute("articulo", aux);
        String fechaFormateada = aux.getFechaPublicacion().format(DateTimeFormatter.ofPattern("dd MMMM yyyy HH:mm"));
        model.addAttribute("fechaFormateada", fechaFormateada);
         Usuario usuario = (Usuario) session.getAttribute("usuario");

        if (usuario.getRol() == null) {
                model.addAttribute("error", "El usuario no tiene un rol asignado");
                return "redirect:/";
            }
            if (usuario.getRol().equals(RolUsuario.ADMIN)) {
                model.addAttribute("categorias", categoriaRepository.findAll());
                return "VerArticulos-Admin"; // Redirigir al dashboard de admin
            } else if (usuario.getRol().equals(RolUsuario.REDACTOR)) {
                model.addAttribute("categorias", categoriaRepository.findAll());
                return "VerArticulos-redactor"; // Redirigir al dashboard de redactor
            } else {
                model.addAttribute("categorias", categoriaRepository.findAll());
                return "VerArticulos"; // Redirigir a una página de error o lista de artículos
            }
    }  

    // Método para activar/desactivar comentarios con seguridad hecha                           <----- AQUÍ
    @GetMapping("/Ver/{id}/cambiarEstado")
    public String setComentariosActivos(boolean comentariosActivos, @PathVariable Long id, Model model, HttpSession session) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");
        Articulo aux = articuloRepository.findById(id).orElseThrow();
        if(usuario.getId() == null || usuario.getId() == 0){

            System.out.println("El ID de usuario no puede ser nulo o vacío");
        }
        else {   
            if(!usuario.getId().equals(aux.getAutor().getId())){
                System.out.println("Solo el Autor puede activar/desactivar los comentarios de su artículo");
            }
            else{
                if (estado) {
                    estado=false;
                }
                else {
                    estado=true;
                }
                articuloRepository.findById(id).orElseThrow().setComentariosActivos(estado);
                articuloService.guardarArticulo(aux, usuario);
                model.addAttribute("articulo", aux);
                model.addAttribute("estado", estado);
                
            }
        }
        return "redirect:/articulos/Ver/{id}"; // Redirigir a la vista del artículo
    }

    @GetMapping("/Filtrar")
    public String FiltrarArticulo(Model model) {
        model.addAttribute("categorias", categoriaRepository.findAll());
        return "lista-articulos-Filtro"; // Vista para filtrar artículos por categoría
    }


    @PostMapping("/Filtro")
    public String listarArticulosFiltrado(@RequestParam("categoria.id") Long id, Model model) {
        Categoria catAux = categoriaRepository.findById(id).orElseThrow();
        if(catAux.getNombre().equals("Todos")){
            model.addAttribute("articulos", articuloRepository.findAll());
            return "lista-articulos";
        }
        else
        {
            model.addAttribute("articulos", articuloRepository.findByCategoria(catAux));     
        }
        
        return "lista-articulos";
    }

    

    @GetMapping("/nuevo")
    public String mostrarFormularioNuevo(Model model) {
        model.addAttribute("articulo", new Articulo());
        model.addAttribute("categorias", categoriaRepository.findAll()); // Opcional
        return "formulario-articulo";
    }
    /*  @PostMapping("/guardar")
    public String guardarArticulo(@ModelAttribute Articulo articulo, Usuario usuario) {

        //articuloRepository.save(articulo);                                            <--- AQUÍ
        articulo.setFechaPublicacion(LocalDateTime.now());                      
        articuloService.guardarArticulo(articulo, usuario);

        return "redirect:/articulos";
    }  */

    @PostMapping("/guardar")
    public String guardarArticulo(@ModelAttribute Articulo articulo, HttpSession session) {

        //articuloRepository.save(articulo);
        Usuario usuario = (Usuario) session.getAttribute("usuario");
        if(usuario.getRol() == RolUsuario.ADMIN) {
            return "redirect:/articulos/admin";   
        }  
        else if(usuario.getRol() == RolUsuario.LECTOR) {
            return "redirect:/articulos";   
        }
        articulo.setFechaPublicacion(LocalDateTime.now());                      
        articuloService.guardarArticulo(articulo, usuario);
        return "redirect:/articulos/redactor"; // Redirige a la lista de artículos del redactor
    }

    @GetMapping("/editar/{id}")
    public String mostrarFormularioEditar(@PathVariable Long id, Model model) {
        model.addAttribute("articulo", articuloRepository.findById(id).orElseThrow());
        model.addAttribute("categorias", categoriaRepository.findAll()); // Opcional
        return "formulario-articulo-edit"; // Redirige al formulario de ediciÃ³n
    }

    @PostMapping("/editarA/{id}")
    public String editarArticulo(@ModelAttribute Articulo cambios, HttpSession session) {        
        Usuario usuario = (Usuario) session.getAttribute("usuario");

        Long id = cambios.getId();

        Articulo aux = articuloRepository.findById(id).orElseThrow();
        
        if(usuario.getRol() == RolUsuario.LECTOR) {
            return "redirect:/articulos";   
        }
        else if(!aux.getAutor().getId().equals(usuario.getId()) && usuario.getRol() != RolUsuario.ADMIN) {
            return "redirect:/articulos/redactor";      
        }
        cambios.setFechaPublicacion(aux.getFechaPublicacion());
        articuloRepository.findById(id).orElseThrow().setFechaPublicacion(cambios.getFechaPublicacion());
        articuloRepository.findById(id).orElseThrow().setCategoria(cambios.getCategoria());
        articuloRepository.findById(id).orElseThrow().setCuerpo(cambios.getCuerpo());
        articuloRepository.findById(id).orElseThrow().setTitulo(cambios.getTitulo());
        articuloService.guardarArticulo(cambios, usuario);

        if (usuario.getRol() == RolUsuario.ADMIN) {
            return "redirect:/articulos/admin";   
        } 

        return "redirect:/articulos/redactor"; // Redirige a la lista de artículos del redactor
    }

    
    @GetMapping("/redireccion")
    public String redireccion( HttpSession session) {        
        Usuario usuario = (Usuario) session.getAttribute("usuario");
        if(usuario.getRol() == RolUsuario.LECTOR) {
            return "redirect:/articulos";   
        }
    
        if (usuario.getRol() == RolUsuario.ADMIN) {
            return "redirect:/articulos/admin";   
        } 

        return "redirect:/articulos/redactor"; // Redirige a la lista de artículos del redactor
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarArticulo(@PathVariable Long id, HttpSession session) {        
        Usuario usuario = (Usuario) session.getAttribute("usuario");
        Articulo aux = articuloRepository.findById(id).orElseThrow();

        if(usuario.getRol() == RolUsuario.LECTOR) {
            return "redirect:/articulos";   
        }
        else if(!aux.getAutor().getId().equals(usuario.getId())) {
            return "redirect:/articulos/redactor";   
        }
        articuloRepository.deleteById(id);   
        if (usuario.getRol() == RolUsuario.ADMIN) {
            return "redirect:/articulos/admin";   
        } 
            
        return "redirect:/articulos/redactor"; // Redirige a la lista de artículos del redactor
    }
    
    


}
