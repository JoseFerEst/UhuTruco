package com.prueba.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prueba.demo.model.Articulo;
import com.prueba.demo.model.Comentario;
import com.prueba.demo.model.RolUsuario;
import com.prueba.demo.model.Usuario;
import com.prueba.demo.repository.ArticuloRepository;  // Import añadido
import com.prueba.demo.repository.ComentarioRepository;

@Service
public class ComentarioService {
    @Autowired
    private ComentarioRepository comentarioRepository;
    
    @Autowired  // Inyección añadida
    private ArticuloRepository articuloRepository;

    // Un redactor solo puede eliminar comentarios en sus artículos
    public void eliminarComentario(Long id, Usuario usuario) {
        Comentario comentario = comentarioRepository.findById(id).orElseThrow();
        boolean esAutorArticulo = comentario.getArticulo().getAutor().getId().equals(usuario.getId());
        boolean esAdmin = usuario.getRol().equals(RolUsuario.ADMIN);
        
        if (!esAutorArticulo && !esAdmin && !comentario.getAutor().getId().equals(usuario.getId())) {
            throw new SecurityException("No tienes permisos para eliminar este comentario");
        }
        comentarioRepository.delete(comentario);
    }

    public void crearComentario(Comentario comentario, Usuario usuario, Long articuloId) {
    Articulo articulo = articuloRepository.findById(articuloId)
        .orElseThrow(() -> new IllegalArgumentException("Artículo no encontrado"));
    if (!articulo.isComentariosActivos()) {
        throw new IllegalStateException("Los comentarios están desactivados para este artículo");
    }
    comentario.setArticulo(articulo);
    comentario.setAutor(usuario);
    comentarioRepository.save(comentario);
}

}