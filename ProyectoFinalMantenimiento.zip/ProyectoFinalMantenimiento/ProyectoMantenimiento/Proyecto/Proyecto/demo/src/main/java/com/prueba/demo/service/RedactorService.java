package com.prueba.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prueba.demo.model.RolUsuario;
import com.prueba.demo.model.Usuario;
import com.prueba.demo.repository.UsuarioRepository;

@Service
public class RedactorService {
    
    @Autowired
    private UsuarioRepository usuarioRepository;
    
    public List<Usuario> findAllRedactores() {
        return usuarioRepository.findByRol(RolUsuario.REDACTOR);
    }
    
    public Optional<Usuario> findRedactorById(Long id) {
        return usuarioRepository.findById(id)
                .filter(usuario -> usuario.getRol() == RolUsuario.REDACTOR);
    }
    
    public Usuario updateRedactor(Usuario redactor) {
        // Asegurarnos de que mantenga el rol REDACTOR
        redactor.setRol(RolUsuario.REDACTOR);
        return usuarioRepository.save(redactor);
    }
    
    public void deleteRedactor(Long id) {  
        usuarioRepository.deleteById(id);
    }
    public Usuario createRedactor(Usuario redactor) {
        redactor.setRol(RolUsuario.REDACTOR); // Asegurarnos de que el rol sea REDACTOR
        return usuarioRepository.save(redactor); 

    }
}