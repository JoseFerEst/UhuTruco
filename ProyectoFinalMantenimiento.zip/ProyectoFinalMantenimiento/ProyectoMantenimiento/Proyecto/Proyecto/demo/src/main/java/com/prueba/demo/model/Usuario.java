package com.prueba.demo.model;

import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;

@Entity
@Table(name = "usuarios")
public class Usuario {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false, length = 100) // Limitar longitud
    private String nombre;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private RolUsuario rol; // Enum: LECTOR, REDACTOR, ADMIN

   @OneToMany(mappedBy = "autor", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Articulo> articulos = new ArrayList<>();

    @OneToMany(mappedBy = "autor", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Comentario> comentarios = new ArrayList<>();
    

    public Usuario() {
    }

    public Usuario(Long id, String email, String password, String nombre, RolUsuario rol) {
        this.id = id;
        this.email = email;
        this.password = password;
        this.nombre = nombre;
        this.rol = rol;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public RolUsuario getRol() {
        return rol;
    }

    public void setRol(RolUsuario rol) {
        this.rol = rol;
    }
/*
    // Métodos para manejar artículos y comentarios                                                 <----- AQUÍ
    public boolean Comentar(Articulo articulo, Comentario comentario) {
        int contador = 0;
        boolean result = false;
        while (contador < articulos.size() && result == false) {
            if(articulo.getId().equals(articulos.get(contador).getId())) {
                articulos.get(contador).agregarComentario(comentario, id);
                result = true;
            }
        }
        return result;
    }

    public boolean eliminarComentario(Articulo articulo, Comentario comentario) {
        int contador = 0;
        boolean result = false;
        while (contador < articulos.size() && result == false) {
            if(articulo.getId().equals(articulos.get(contador).getId())) {
                articulos.get(contador).eliminarComentario(comentario, id);
                result = true;
            }
        }
        return result;
    }
*/
    public List<Articulo> getArticulos() {
        return articulos;
    }

    public void setArticulos(List<Articulo> articulos) {
        this.articulos = articulos;
    }

    public List<Comentario> getComentarios() {
        return comentarios;
    }

    public void setComentarios(List<Comentario> comentarios) {
        this.comentarios = comentarios;
    }
}