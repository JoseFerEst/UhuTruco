package com.prueba.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.prueba.demo.model.Categoria;
import com.prueba.demo.model.RolUsuario;
import com.prueba.demo.model.Usuario;
import com.prueba.demo.service.CategoriaService;
import com.prueba.demo.repository.CategoriaRepository;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/categorias")
public class CategoriaController {

    @Autowired
    private CategoriaService categoriaService;
    @Autowired
    private CategoriaRepository categoriaRepository;

    @GetMapping
    public String listarCategorias(Model model) {
        model.addAttribute("categorias", categoriaService.listarTodas());
        return "lista-categorias";
    }

    @GetMapping("/nueva")
    public String formularioNueva(Model model, HttpSession session) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");
        if(usuario.getRol() != RolUsuario.ADMIN) {
            return "redirect:/categorias";   
        } 
        model.addAttribute("categoria", new Categoria());
        return "formulario-categoria";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute Categoria categoria, HttpSession session) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");
        if(usuario.getRol() != RolUsuario.ADMIN) {
            return "redirect:/categorias";   
        } 
        categoriaService.crearCategoria(categoria); // Solo admins, validado dentro del servicio
        return "redirect:/categorias";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, HttpSession session) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");
        if(usuario.getRol() != RolUsuario.ADMIN) {
            return "redirect:/categorias";   
        } 
        //Usuario usuario = (Usuario) session.getAttribute("usuario");
        categoriaRepository.deleteById(id); // Verifica que la categoría exista
        //categoriaService.eliminarCategoria(id, usuario);
        return "redirect:/categorias";
    }

    @GetMapping("/editar/{id}")
    public String mostrarFormularioEditar(@PathVariable Long id, Model model) {
        Categoria categoria = categoriaRepository.findById(id).orElseThrow();
        model.addAttribute("categoria", categoria);
        return "formulario-categoria-edit"; // Redirige al formulario de edición
    }

    @PostMapping("/editarC/{id}") 
    public String editar(@PathVariable Long id, @ModelAttribute Categoria categoria, HttpSession session) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");
        if(usuario.getRol() != RolUsuario.ADMIN) {
            return "redirect:/categorias";   
        }
        Categoria categoriaExistente = categoriaRepository.findById(id).orElseThrow();
        categoriaExistente.setNombre(categoria.getNombre());
        categoriaExistente.setDescripcion(categoria.getDescripcion());
        categoriaRepository.save(categoriaExistente);
        // Si necesitas lógica adicional, llama a categoriaService.actualizarCategoria(id, categoria, usuario);

        return "redirect:/categorias";
    }
    

}
