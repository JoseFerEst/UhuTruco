package com.prueba.demo.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.prueba.demo.model.RolUsuario;
import com.prueba.demo.model.Usuario;
import com.prueba.demo.repository.CategoriaRepository;
import com.prueba.demo.service.UsuarioService;

import jakarta.servlet.http.HttpSession;

@Controller
public class LoginController {

    @Autowired
    private UsuarioService usuarioService;
    @Autowired
    private CategoriaRepository categoriaRepository;

    @GetMapping("/login")
    public String mostrarLogin(Model model) {
        return "login";
    }

    @PostMapping("/login")
    public String login(@RequestParam String email, @RequestParam String password,
                        HttpSession session, Model model) {
        Optional<Usuario> optUsuario = usuarioService.buscarPorEmail(email);
        if (optUsuario.isPresent() && optUsuario.get().getPassword().equals(password)) 
        {
            session.setAttribute("usuario", optUsuario.get());
            Usuario usuario = optUsuario.get();
            if (usuario.getRol() == null) {
                model.addAttribute("error", "El usuario no tiene un rol asignado");
                return "redirect:/";
            }
            if (usuario.getRol().equals(RolUsuario.ADMIN)) {
                model.addAttribute("categorias", categoriaRepository.findAll());
                return "redirect:/usuarios/home"; // Redirigir al dashboard de admin
            } else if (usuario.getRol().equals(RolUsuario.REDACTOR)) {
                model.addAttribute("categorias", categoriaRepository.findAll());
                return "redirect:/usuarios/home-redactor"; // Redirigir al dashboard de redactor
            } else {
                model.addAttribute("categorias", categoriaRepository.findAll());
                return "redirect:/articulos"; // Redirigir a una página de error o lista de artículos
            }
            
        } else {
            model.addAttribute("error", "Email o contraseña incorrectos");
            return "redirect:/";
        }
    }

    

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }
}
