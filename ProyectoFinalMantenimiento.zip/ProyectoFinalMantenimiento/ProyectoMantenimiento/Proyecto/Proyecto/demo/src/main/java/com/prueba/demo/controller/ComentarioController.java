package com.prueba.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import com.prueba.demo.model.Articulo;
import com.prueba.demo.model.Comentario;
import com.prueba.demo.model.Usuario;
import com.prueba.demo.repository.ArticuloRepository;
import com.prueba.demo.service.ComentarioService;

import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("/comentarios")
public class ComentarioController {

    @Autowired
    private ComentarioService comentarioService;

    @Autowired
    private ArticuloRepository articuloRepository;

    

    // POST para crear comentario
    @PostMapping("/crear/{articuloId}")
    public String crearComentario(@PathVariable Long articuloId,
                                  @ModelAttribute Comentario comentario,
                                  HttpSession session) {

        Articulo articulo = articuloRepository.findById(articuloId).orElseThrow();
        System.out.println(articulo.isComentariosActivos());
        if(articulo.isComentariosActivos()==false){
            return "redirect:/articulos/Ver/" + articuloId;
        }
        Usuario usuario = (Usuario) session.getAttribute("usuario");
        comentarioService.crearComentario(comentario, usuario, articuloId);
        return "redirect:/articulos/Ver/" + articuloId;
    }

    // GET para eliminar comentario
    @PostMapping("/eliminar/{id}")
    public String eliminarComentario(@PathVariable Long id, HttpSession session,@RequestParam Long articuloId) {
        Usuario usuario = (Usuario) session.getAttribute("usuario");
        comentarioService.eliminarComentario(id, usuario);
        return "redirect:/articulos/Ver/"+ articuloId;
    }


    
}
