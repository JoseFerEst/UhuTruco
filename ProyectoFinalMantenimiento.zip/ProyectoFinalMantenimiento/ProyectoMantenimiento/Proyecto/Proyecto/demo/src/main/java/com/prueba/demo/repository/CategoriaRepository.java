package com.prueba.demo.repository;

import com.prueba.demo.model.Categoria;



import org.springframework.data.jpa.repository.JpaRepository;

public interface CategoriaRepository extends JpaRepository<Categoria, Long> {
    // Método para verificar si existe una categoría por su nombre
    boolean existsByNombre(String nombre);
    
    /* 
    List<Categoria> findByNombre(String nombre);
    // Método para buscar categorías por descripción
    List<Categoria> findByDescripcion(String descripcion);
    */
}