package com.prueba.demo.model;

public enum RolUsuario {
    LECTOR {
        @Override
        public boolean puedeComentar(Articulo articulo) {
            return articulo.isComentariosActivos();  // Solo si están activos
        }
        @Override
        public boolean puedeEditarArticulo(Articulo articulo, Usuario usuario) {
            return false;  // Lectores no editan
        }
    },
    REDACTOR {
        @Override
        public boolean puedeComentar(Articulo articulo) {
            return true;  // Redactores siempre pueden comentar
        }
        @Override
        public boolean puedeEditarArticulo(Articulo articulo, Usuario usuario) {
            return articulo.getAutor().equals(usuario);  // Solo sus artículos
        }
    },
    ADMIN {
        @Override
        public boolean puedeComentar(Articulo articulo) {
            return true;  // Admins pueden todo
        }
        @Override
        public boolean puedeEditarArticulo(Articulo articulo, Usuario usuario) {
            return true;  // Admins pueden editar cualquier artículo
        }
    };
    
    // Métodos abstractos que cada valor debe implementar
    public abstract boolean puedeComentar(Articulo articulo);
    public abstract boolean puedeEditarArticulo(Articulo articulo, Usuario usuario);
}