package com.prueba.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.prueba.demo.model.Categoria;
import com.prueba.demo.model.RolUsuario;
import com.prueba.demo.model.Usuario;
import com.prueba.demo.repository.CategoriaRepository;

@Service
public class CategoriaService {
    @Autowired
    private CategoriaRepository categoriaRepository;
    
    public Categoria crearCategoria(Categoria categoria) {
        if (categoriaRepository.existsByNombre(categoria.getNombre())) {
            throw new IllegalArgumentException("Ya existe una categoría con este nombre");
        }
        return categoriaRepository.save(categoria);
    }

    public void eliminarCategoria(Long id, Usuario usuario) {
        if (!usuario.getRol().equals(RolUsuario.ADMIN)) {
            throw new SecurityException("Solo los administradores pueden eliminar categorías");
        }
        categoriaRepository.deleteById(id);
    }

    public List<Categoria> listarTodas() {
        return categoriaRepository.findAll();
    }

    public Categoria actualizarCategoria(Long id, Categoria cambios, Usuario usuario) {
    Long idPrueba = 2L; // ID de prueba
    usuario = new Usuario(idPrueba, "admin@email.com", "1234", "admin", RolUsuario.ADMIN);
    if (!usuario.getRol().equals(RolUsuario.ADMIN)) {
        throw new SecurityException("Solo los administradores pueden editar categorías");
    }
    Categoria categoria = categoriaRepository.findById(id).orElseThrow();
    categoria.setNombre(cambios.getNombre());
    categoria.setDescripcion(cambios.getDescripcion());
    return categoriaRepository.save(categoria);
}
}