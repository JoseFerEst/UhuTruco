package com.prueba.demo.repository;
import org.springframework.stereotype.Repository;

import com.prueba.demo.model.Articulo;
import com.prueba.demo.model.Comentario;
import com.prueba.demo.model.Usuario;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;   

@Repository
public interface ComentarioRepository extends JpaRepository<Comentario, Long> {
     // Para buscar comentarios por autor
    List<Comentario> findByAutor(Usuario autor);
    @Query("SELECT c.articulo.id, COUNT(c) FROM Comentario c GROUP BY c.articulo.id")
List<Object[]> contarComentariosPorArticulo();
List<Comentario> findByArticulo(Articulo articulo);
List<Comentario> findByTextoContainingIgnoreCase(String texto);
}

