package com.prueba.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.prueba.demo.model.Articulo;
import com.prueba.demo.model.RolUsuario;
import com.prueba.demo.model.Usuario;
import com.prueba.demo.repository.ArticuloRepository;
import com.prueba.demo.repository.CategoriaRepository;

@Service
public class ArticuloService {
    @Autowired
    private ArticuloRepository articuloRepository;

    @Autowired
    private CategoriaRepository categoriaRepository;

    public void guardarArticulo(Articulo articulo, Usuario usuario) {
        //Long idPrueba = 1L; // ID de prueba
        //usuario = new Usuario(idPrueba, "emailprueba@email.com", "1234567890", "Pepe", RolUsuario.REDACTOR);
        if (articulo.getCategoria() == null || !categoriaRepository.existsById(articulo.getCategoria().getId())) {
            throw new IllegalArgumentException("La categoría no existe");
        }
        articulo.setAutor(usuario);
        articuloRepository.save(articulo);
    }

    public void eliminarArticulo(Long id, Usuario usuario) {
        //Long idPrueba = 1L; // ID de prueba
        //usuario = new Usuario(idPrueba, "emailprueba@email.com", "1234567890", "Pepe", RolUsuario.REDACTOR);
        
        Articulo articulo = articuloRepository.findById(id).orElseThrow();
        if (!usuario.getRol().equals(RolUsuario.ADMIN) && !articulo.getAutor().equals(usuario)) {
            throw new SecurityException("Acceso denegado");
        }
        articuloRepository.delete(articulo);
    }
    
    //revisar
    public Articulo editarArticulo(Long id, Articulo cambios, Usuario usuario) {
        //Long idPrueba = 1L; // ID de prueba
        //usuario = new Usuario(idPrueba, "emailprueba@email.com", "1234567890", "Pepe", RolUsuario.REDACTOR);
        
        Articulo articulo = articuloRepository.findById(id).orElseThrow();
        if (!usuario.getRol().equals(RolUsuario.ADMIN) && !articulo.getAutor().equals(usuario)) {
            throw new SecurityException("No tienes permisos para editar este artículo");
        }
        articulo.setTitulo(cambios.getTitulo());
        articulo.setCuerpo(cambios.getCuerpo());
        articulo.setCategoria(cambios.getCategoria());
        return articuloRepository.save(articulo);
    }

    public Articulo obtenerArticuloPorId(Long id) {
        return articuloRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("Artículo no encontrado"));
    }
}
