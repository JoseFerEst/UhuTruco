package com.prueba.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.prueba.demo.model.RolUsuario;
import com.prueba.demo.model.Usuario;
import com.prueba.demo.service.UsuarioService;

@Controller
@RequestMapping("/auth")
public class AuthController {

    @Autowired
    private UsuarioService usuarioService;

    // Mostrar formulario de registro
    @GetMapping("/registro")
    public String mostrarFormularioRegistro(Model model) {
        Usuario usuario = new Usuario();
        usuario.setRol(RolUsuario.LECTOR); // Asignar rol por defecto
        model.addAttribute("usuario", usuario);
        return "formulario-registro"; // Asegúrate de tener formulario-registro.html en templates/
    }

    // Procesar registro   
    @PostMapping("/registro")  
    public String registrarLector(@ModelAttribute Usuario usuario) {
        usuario.setRol(RolUsuario.LECTOR);
        usuarioService.registrarUsuario(usuario);
        return "redirect:/";
    }

    @GetMapping("/login")
    public String mostrarLogin(@RequestParam(required = false) String registroExitoso, Model model) {
        if (registroExitoso != null) {
            model.addAttribute("mensaje", "¡Registro exitoso! Ahora inicia sesión.");
        }
        return "/"; // Asegúrate de tener login.html en templates/
    }

}
    // Mostrar formulario de login (ya lo tienes en LoginController)
    // ...
