package com.prueba.demo.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "articulos")
public class Articulo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Size(min = 10, max = 200, message = "El título debe tener entre 10 y 200 caracteres")
    private String titulo;

    @Column(columnDefinition = "TEXT", nullable = false) // Para textos largos
    private String cuerpo;

    @Column(name = "fecha_publicacion", nullable = false)
    private LocalDateTime fechaPublicacion;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "autor_id", nullable = false)
    private Usuario autor;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "categoria_id", nullable = false)
    private Categoria categoria;


    @OneToMany(mappedBy = "articulo", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Comentario> comentarios = new ArrayList<>();

    @Column(nullable = false)
    private boolean comentariosActivos = true; // Para desactivar comentarios



    public Articulo() {
    }

    public Articulo(String titulo, String cuerpo, LocalDateTime fechaPublicacion, Usuario autor, Categoria categoria, boolean comentariosActivos) {
        this.titulo = titulo;
        this.cuerpo = cuerpo;
        this.fechaPublicacion = fechaPublicacion;
        this.autor = autor;
        this.categoria = categoria;
        this.comentariosActivos = comentariosActivos;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getCuerpo() {
        return cuerpo;
    }

    public void setCuerpo(String cuerpo) {
        this.cuerpo = cuerpo;
    }

    public LocalDateTime getFechaPublicacion() {
        return fechaPublicacion;
    }

    public void setFechaPublicacion(LocalDateTime fechaPublicacion) {
        this.fechaPublicacion = fechaPublicacion;
    }

    public Usuario getAutor() {
        return autor;
    }

    public void setAutor(Usuario autor) {
        this.autor = autor;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public List<Comentario> getComentarios() {
        return comentarios;
    }

    public void setComentarios(List<Comentario> comentarios) {
        this.comentarios = comentarios;
    }

    public boolean isComentariosActivos() {
        return comentariosActivos;
    }
    public void setComentariosActivos(boolean comentariosActivos) {
        this.comentariosActivos = comentariosActivos;
    }


    


    //Métodos Nuevos para gestión de comentarios                                                <----- AQUÍ
    // Método para agregar un comentario
    public void agregarComentario(Comentario comentario, Long idUsuario) {
        if(idUsuario == null || idUsuario == 0){
            System.out.println("El ID de usuario no puede ser nulo o vacío");
        }
        else {
            if (!comentariosActivos) {
                System.out.println("Los comentarios están desactivados para este artículo");
            }
            else{
                //if(idUsuario.equals(idAdmin)){
                //    System.out.println("El administrador no puede comentar");
                //}
                //else{
                    System.out.println("Comentario agregado por el usuario con ID: " + idUsuario);
                //}
            }
        }

        comentarios.add(comentario);
        comentario.setArticulo(this);
    }

    // Método para eliminar un comentario
    public void eliminarComentario(Comentario comentario, Long idUsuario) {
        if(idUsuario == null || idUsuario == 0){
            System.out.println("El ID de usuario no puede ser nulo o vacío");
        }
        else {
            if (!comentariosActivos) {
                System.out.println("Los comentarios están desactivados para este artículo");
            }
            else{
                System.out.println("Comentario eliminado por el usuario con ID: " + idUsuario);
            }
        }
        comentarios.remove(comentario);
        comentario.setArticulo(null);
    }

    // Método para editar un comentario
    public void editarComentario(Comentario comentario, int posi, Long idUsuario) {
        if(idUsuario == null || idUsuario == 0){
            System.out.println("El ID de usuario no puede ser nulo o vacío");
        }
        else {
            if (!comentariosActivos) {
                System.out.println("Los comentarios están desactivados para este artículo");
            }
            else{
                System.out.println("Comentario editado por el usuario con ID: " + idUsuario);
            }
        }

        comentarios.set(posi, comentario);
        comentario.setArticulo(this);
    }
}